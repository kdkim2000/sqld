/* eslint-disable */
/* Quest — additional pages: Theory, Result, Wrong, Bookmarks
   Shares the topbar look from quest.jsx */

// Reusable topbar (matches QuestDesktop)
const QuestTopbar = ({ current = 'home' }) => (
  <div className="q-topbar">
    <div className="q-brand">
      <div className="q-brand-mark">Q</div>
      <span>SQLD 퀘스트</span>
    </div>
    <nav className="q-nav">
      <a className={current==='home'?'on':''}>홈</a>
      <a className={current==='theory'?'on':''}>이론</a>
      <a className={current==='quiz'?'on':''}>문제풀기</a>
      <a className={current==='league'?'on':''}>리그</a>
      <a className={current==='codex'?'on':''}>도감</a>
    </nav>
    <div className="q-stats">
      <span className="q-stat streak"><IFlame size={16}/> 14일</span>
      <span className="q-stat gem"><IGem size={16}/> 1,420</span>
      <span className="q-stat heart"><IHeart size={16}/> 4 / 5</span>
      <span className="q-avatar">진</span>
    </div>
  </div>
);

// ────────────────────────────────────────────────────────
// THEORY — Desktop
// ────────────────────────────────────────────────────────
const QuestTheoryDesktop = () => {
  const toc = [
    { t: '데이터 모델링 개요',             done: true },
    { t: '엔터티 (Entity)',                 done: true },
    { t: '속성 (Attribute)',                done: true },
    { t: '관계 (Relationship)',             done: false, on: true },
    { t: '식별자 (Identifier)',             done: false },
    { t: '주식별자 vs 외래식별자',           done: false },
    { t: '미니 시험 · 10문항',               done: false, mini: true },
  ];

  return (
    <div className="q q-canvas">
      <QuestTopbar current="theory"/>

      <div className="q-theory-grid">
        {/* TOC */}
        <aside className="q-toc">
          <div className="q-toc-title">목차 · 1과목 1장</div>
          {toc.map((x, i) => (
            <div key={i} className={`q-toc-item ${x.done?'done':''} ${x.on?'on':''}`}>
              <span className="ic">
                {x.done ? <ICheck size={12}/> : x.mini ? <ITrophy size={12}/> : i+1}
              </span>
              {x.t}
            </div>
          ))}
          <div style={{ height: 1, background: 'var(--q-border)', margin: '12px 4px' }}/>
          <div className="q-toc-title">다음 챕터</div>
          <div className="q-toc-item">
            <span className="ic"><ILock size={12}/></span>
            데이터 모델과 성능
          </div>
        </aside>

        {/* Reading body */}
        <article className="q-prose">
          <div className="q-prose-progress">
            <span className="label">진행률</span>
            <div className="track"><div className="fill" style={{ width: '52%' }}/></div>
            <span className="pct">52%</span>
            <span style={{ fontSize: 12, color: 'var(--q-ink-3)', fontFamily: 'var(--font-mono)' }}>+15 XP 적립 중</span>
          </div>

          <span className="q-prose-eyebrow"><IBook size={12}/> 이론 학습 · 약 4분</span>
          <h1>관계 (Relationship)</h1>
          <p style={{ color: 'var(--q-ink-3)', fontSize: 14, fontFamily: 'var(--font-mono)' }}>
            데이터 모델링의 이해 · 1.4
          </p>

          <p className="lead">
            <b>관계(Relationship)</b>는 엔터티 사이에 존재하는 연관성을 의미하며,
            <b> 카디널리티</b>와 <b>참여도</b>로 표현한다. 시험에서는 1:N, N:M 관계 식별과
            관계의 표기법(IE/Barker 표기)이 자주 출제된다.
          </p>

          <h2>관계의 표기 방식</h2>
          <p>
            관계는 <span className="q-keyword">관계명(Relationship Name)</span>·
            <span className="q-keyword">관계차수(Cardinality)</span>·
            <span className="q-keyword">관계선택사양(Optionality)</span>의 3요소로 정의된다.
            대부분의 ERD 도구는 <b>IE 표기법</b>(Information Engineering, 새발 표기)을 따른다.
          </p>

          <table className="er-table">
            <thead>
              <tr>
                <th>표기</th><th>의미</th><th>예시</th>
              </tr>
            </thead>
            <tbody>
              <tr><td>┃</td><td>필수 (1)</td><td>사원은 반드시 한 부서에 소속</td></tr>
              <tr><td>○</td><td>선택 (0)</td><td>고객은 주문이 없을 수도 있음</td></tr>
              <tr><td>⋞</td><td>다수 (N)</td><td>한 부서는 여러 사원을 가짐</td></tr>
            </tbody>
          </table>

          <h2>SQL로 관계 검증하기</h2>
          <p>
            ERD로 표현된 1:N 관계는 SQL에서 <b>외래키 (FK) 제약조건</b>으로 구현된다.
            아래는 부서(<b>1</b>) — 사원(<b>N</b>) 관계의 예시이다.
          </p>

          <pre>
<span className="cm">{`-- 부서(1) - 사원(N) 관계`}</span>{'\n'}
<span className="kw">CREATE TABLE</span> DEPT (
  DEPTNO   <span className="lit">NUMBER(2)</span>   <span className="kw">PRIMARY KEY</span>,
  DNAME    <span className="lit">VARCHAR2(20)</span> <span className="kw">NOT NULL</span>
);{'\n\n'}
<span className="kw">CREATE TABLE</span> EMP (
  EMPNO    <span className="lit">NUMBER(4)</span>   <span className="kw">PRIMARY KEY</span>,
  ENAME    <span className="lit">VARCHAR2(20)</span>,
  DEPTNO   <span className="lit">NUMBER(2)</span>
    <span className="kw">REFERENCES</span> <span className="fn">DEPT</span>(DEPTNO) <span className="cm">{`-- FK`}</span>
);
          </pre>

          <div className="q-callout">
            <div className="ic-circle">!</div>
            <div className="body">
              <strong>자주 틀리는 포인트</strong>
              <p>관계는 항상 양방향이다. "부서 ⟵ 사원"이라는 관계도 "부서가 사원을 보유한다" 또는 "사원이 부서에 소속된다"로 양쪽 모두 명명되어야 한다.</p>
            </div>
          </div>

          <h2>식별 vs 비식별 관계</h2>
          <p>
            <b>식별 관계(Identifying)</b>는 부모 엔터티의 식별자가 자식의 주식별자에 포함되는 경우,
            <b> 비식별 관계(Non-identifying)</b>는 외래키이지만 주식별자가 아닌 경우를 말한다.
            ERD에서 식별 관계는 <b>실선</b>, 비식별 관계는 <b>점선</b>으로 표기한다.
          </p>

          <div className="q-mascot-tip">
            <Querymon size={70}/>
            <div>
              <div className="speech-tag">쿼리몬이 알려줘요</div>
              <p style={{ margin: 0, fontSize: 13, color: 'var(--q-ink-2)', lineHeight: 1.55 }}>
                시험에서 "관계의 표기법"은 거의 매 회 나옵니다. 특히 <b>새발(crow's foot) 표기에서 1과 N의 위치를 헷갈리지 마세요</b> — N이 자식(Many) 쪽에 표기됩니다.
              </p>
            </div>
          </div>

          <div className="q-prose-foot">
            <button className="prev">‹ 속성 (Attribute)</button>
            <div style={{ fontSize: 12, color: 'var(--q-ink-3)' }}>읽고 나서 미니 시험 +50XP 💎</div>
            <button className="next">식별자 (Identifier) ›</button>
          </div>
        </article>

        {/* Right rail */}
        <aside style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div className="q-card">
            <div className="q-card-title">관련 문제 <span className="small">3 / 28</span></div>
            {[
              { q: '다음 중 관계의 표기 요소가 아닌 것은?', diff: '중', done: true },
              { q: 'IE 표기법에서 N의 위치로 옳은 것은?',     diff: '하', done: false },
              { q: '식별 관계와 비식별 관계의 차이는?',        diff: '상', done: false },
            ].map((q, i) => (
              <div key={i} style={{
                padding: '10px 0',
                borderBottom: i < 2 ? '1px dashed var(--q-border-2)' : 0,
                display: 'flex', alignItems: 'center', gap: 8
              }}>
                <span style={{
                  width: 18, height: 18, borderRadius: 6, flexShrink: 0,
                  background: q.done ? '#12B76A' : 'var(--q-surface-soft)',
                  color: q.done ? '#fff' : 'var(--q-ink-3)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 10
                }}>{q.done ? <ICheck size={11}/> : ''}</span>
                <span style={{ flex: 1, fontSize: 13, color: 'var(--q-ink)' }}>{q.q}</span>
                <span style={{ fontSize: 10, color: 'var(--q-ink-3)', fontFamily: 'var(--font-mono)' }}>{q.diff}</span>
              </div>
            ))}
            <button style={{
              width: '100%', marginTop: 10, padding: 10, borderRadius: 10,
              background: '#7F56D9', color: '#fff', border: 0,
              fontWeight: 700, fontSize: 13, cursor: 'pointer',
              boxShadow: '0 3px 0 #53389E'
            }}>이 챕터 문제 풀기 →</button>
          </div>

          <div className="q-card" style={{ padding: 0, overflow: 'hidden' }}>
            <div style={{
              padding: '14px 18px',
              background: 'linear-gradient(135deg, #F4F3FF, #FFE5F1)',
              borderBottom: '1px solid var(--q-border)'
            }}>
              <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '.04em', color: '#53389E' }}>오늘의 학습 보상</div>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 18, marginTop: 4, color: 'var(--q-ink)' }}>
                3챕터 더 읽으면 💎+200
              </div>
            </div>
            <div style={{ padding: 18 }}>
              <div style={{ display: 'flex', gap: 4, alignItems: 'center', marginBottom: 8 }}>
                {[1,1,1,0,0].map((on, i) => (
                  <div key={i} style={{
                    flex: 1, height: 8, borderRadius: 999,
                    background: on ? '#7F56D9' : 'var(--q-border)'
                  }}/>
                ))}
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, fontWeight: 800, color: 'var(--q-ink-2)', marginLeft: 8 }}>3 / 5</span>
              </div>
              <div style={{ fontSize: 12, color: 'var(--q-ink-2)', lineHeight: 1.5 }}>
                오늘 이미 3챕터 읽으셨어요! 2챕터만 더 읽으면 보너스를 받아요.
              </div>
            </div>
          </div>

          <div className="q-card">
            <div className="q-card-title">함께 보면 좋은 자료</div>
            {['📖 정규형 1NF~3NF 한 페이지 요약', '🎬 ERD로 보는 관계 (3분)', '📝 출제 빈도 분석 — 1과목'].map((t, i) => (
              <a key={i} style={{
                display: 'flex', padding: '8px 0',
                borderBottom: i < 2 ? '1px dashed var(--q-border)' : 0,
                fontSize: 13, color: 'var(--q-ink)', cursor: 'pointer', fontWeight: 500
              }}>{t}</a>
            ))}
          </div>
        </aside>
      </div>
    </div>
  );
};

// ────────────────────────────────────────────────────────
// THEORY — Mobile
// ────────────────────────────────────────────────────────
const QuestTheoryMobile = () => (
  <div className="q-mobile">
    <div style={{
      padding: '14px 16px 14px',
      background: 'linear-gradient(180deg, #7F56D9, #6941C6)',
      color: '#fff'
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
        <button style={{ background: 'rgba(255,255,255,.18)', border: 0, color: '#fff', width: 30, height: 30, borderRadius: 9 }}>‹</button>
        <div style={{ fontSize: 11, opacity: .85, fontWeight: 600 }}>1과목 · 1장</div>
        <div style={{ marginLeft: 'auto', display: 'inline-flex', alignItems: 'center', gap: 6, padding: '4px 10px', borderRadius: 999, background: 'rgba(255,255,255,.18)', fontSize: 11, fontWeight: 700 }}>
          <IGem size={12}/> +15
        </div>
      </div>
      <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 20, marginBottom: 4 }}>
        관계 (Relationship)
      </div>
      <div style={{ fontSize: 12, opacity: .85, fontFamily: 'var(--font-mono)' }}>1.4 · 약 4분</div>
      <div style={{ height: 6, background: 'rgba(0,0,0,.2)', borderRadius: 999, marginTop: 12, overflow: 'hidden' }}>
        <div style={{ width: '52%', height: '100%', background: '#FAC515', borderRadius: 999 }}/>
      </div>
    </div>

    <div className="q-mobile-body" style={{ background: 'var(--q-bg)' }}>
      <article className="q-prose" style={{ padding: 20, border: 0, boxShadow: 'none', borderRadius: 0, background: 'transparent' }}>
        <p className="lead" style={{ fontSize: 14, padding: 14 }}>
          <b>관계(Relationship)</b>는 엔터티 사이의 연관성을 의미하며 카디널리티와 참여도로 표현한다.
        </p>

        <h2 style={{ fontSize: 17, margin: '20px 0 8px' }}>관계의 표기 방식</h2>
        <p style={{ fontSize: 14 }}>
          관계는 <span className="q-keyword">관계명</span>·<span className="q-keyword">관계차수</span>·<span className="q-keyword">관계선택사양</span>의 3요소로 정의된다. 대부분의 ERD 도구는 <b>IE 표기법</b>(새발 표기)을 따른다.
        </p>

        <pre style={{ fontSize: 11, padding: 14 }}>
<span className="kw">CREATE TABLE</span> EMP (
  EMPNO    <span className="lit">NUMBER(4)</span>,
  DEPTNO   <span className="lit">NUMBER(2)</span>{'\n'}
    <span className="kw">REFERENCES</span> <span className="fn">DEPT</span>(DEPTNO)
);
        </pre>

        <div className="q-mascot-tip" style={{ padding: 12 }}>
          <Querymon size={52}/>
          <div style={{ flex: 1 }}>
            <div className="speech-tag" style={{ fontSize: 10 }}>쿼리몬 팁</div>
            <p style={{ margin: 0, fontSize: 12, color: 'var(--q-ink-2)', lineHeight: 1.5 }}>
              새발 표기에서 N은 항상 자식(Many) 쪽이에요!
            </p>
          </div>
        </div>

        <h2 style={{ fontSize: 17, margin: '20px 0 8px' }}>식별 vs 비식별 관계</h2>
        <p style={{ fontSize: 14 }}>
          식별 관계는 <b>실선</b>, 비식별 관계는 <b>점선</b>으로 표기한다.
        </p>
      </article>
    </div>

    {/* Sticky bottom */}
    <div style={{
      position: 'absolute', bottom: 0, left: 0, right: 0,
      padding: '12px 16px 24px',
      background: 'var(--q-surface)', borderTop: '1px solid var(--q-border)',
      display: 'flex', gap: 10
    }}>
      <button style={{
        padding: '12px 18px', borderRadius: 12,
        background: 'var(--q-surface-soft)', border: 0,
        color: 'var(--q-ink-2)', fontWeight: 700, fontSize: 13
      }}>‹ 이전</button>
      <button style={{
        flex: 1, padding: '12px 18px', borderRadius: 12,
        background: '#7F56D9', color: '#fff', border: 0,
        fontWeight: 800, fontSize: 14, boxShadow: '0 3px 0 #53389E'
      }}>다음으로 ›</button>
    </div>
  </div>
);

// ────────────────────────────────────────────────────────
// RESULT — Desktop
// ────────────────────────────────────────────────────────
const Confetti = () => {
  const items = [];
  const colors = ['#7F56D9', '#FAC515', '#FF6B6B', '#12B76A', '#84CAFF', '#F670C7'];
  let seed = 11;
  for (let i = 0; i < 36; i++) {
    seed = (seed * 1103515245 + 12345) & 0x7fffffff;
    const r1 = seed / 0x7fffffff;
    seed = (seed * 1103515245 + 12345) & 0x7fffffff;
    const r2 = seed / 0x7fffffff;
    seed = (seed * 1103515245 + 12345) & 0x7fffffff;
    const r3 = seed / 0x7fffffff;
    items.push(
      <span key={i} style={{
        left: `${r1 * 100}%`,
        top: `${r2 * 60}%`,
        background: colors[i % colors.length],
        transform: `rotate(${r3 * 360}deg)`,
      }}/>
    );
  }
  return <div className="q-confetti">{items}</div>;
};

const StarRow = ({ count = 3 }) => (
  <div className="q-result-stars">
    {[0,1,2].map(i => (
      <svg key={i} viewBox="0 0 48 48" fill={i < count ? '#FAC515' : 'transparent'} stroke={i < count ? '#A15C07' : '#D0D5DD'} strokeWidth="2">
        <path d="m24 4 6 14 15 1.5-11 10.5 3 14.5L24 36l-13 8 3-14.5L3 19.5 18 18z"/>
      </svg>
    ))}
  </div>
);

const QuestResultDesktop = () => (
  <div className="q q-canvas">
    <QuestTopbar current="quiz"/>

    <div className="q-result">
      <Confetti/>

      <div className="q-result-hero">
        <Querymon size={150} wave/>
        <div className="stamp">⭐ SQL 기본 — JOIN 미션 완료</div>
        <h1>잘했어요, <span className="gradient">진수님!</span></h1>
        <p>10문제 중 9문제 정답 · 정확도 90% · 연속 14일째 학습 중</p>
        <StarRow count={3}/>
      </div>

      <div className="q-result-score">
        {[
          { l: '정답률', v: '90%',   d: '+12%p',   c: '#7F56D9' },
          { l: '획득 XP', v: '+180', d: '레벨 7',   c: '#FFB627' },
          { l: '획득 보석', v: '+50', d: '💎 1,470', c: '#F670C7' },
          { l: '소요 시간', v: '6:24', d: '평균 38초/문제', c: '#12B76A' },
        ].map((x, i) => (
          <div key={i} className="q-result-stat">
            <div className="lbl">{x.l}</div>
            <div className="val" style={{ color: x.c }}>{x.v}</div>
            <div className="delta">{x.d}</div>
          </div>
        ))}
      </div>

      <div className="q-result-row">
        <div className="q-achievement">
          <span className="emoji">🏆</span>
          <div className="body">
            <div className="ttl">새 도전과제 획득!</div>
            <div className="sub">"JOIN 마스터" — JOIN 문제 30문제 정답</div>
          </div>
        </div>
        <div className="q-mascot-evolve">
          <Querymon size={64}/>
          <div className="body">
            <div className="ttl">쿼리몬 진화까지 320 XP</div>
            <div className="sub">다음 진화: 🎓 학자 쿼리몬</div>
          </div>
        </div>
      </div>

      <div className="q-review-strip">
        <div className="q-review-strip-title">문제별 결과</div>
        {[
          { n: 1, ok: true,  q: 'INNER JOIN과 OUTER JOIN의 차이점은?',          t: '0:38' },
          { n: 2, ok: true,  q: 'NATURAL JOIN을 사용했을 때 결과로 적절한 것은?', t: '0:42' },
          { n: 3, ok: true,  q: '다음 SQL의 결과 행 수는?',                       t: '1:08' },
          { n: 4, ok: false, q: 'CROSS JOIN의 결과 행 수 계산 방법은?',           t: '1:24' },
          { n: 5, ok: true,  q: 'USING 절을 사용한 JOIN의 결과는?',              t: '0:31' },
        ].map((x, i) => (
          <div key={i} className="q-review-row">
            <div className={`q-review-num ${x.ok?'ok':'no'}`}>{x.ok ? <ICheck size={14}/> : '✕'}</div>
            <div className="q-review-q">{x.n}. {x.q}</div>
            <div className="q-review-meta">{x.t}</div>
          </div>
        ))}
      </div>

      <div className="q-result-cta">
        <button className="primary"><IPlay size={14}/> 다음 미션 시작</button>
        <button className="secondary"><IRefresh size={14}/> 오답 다시 풀기 (1)</button>
        <button className="secondary"><IBM size={14}/> 결과 공유</button>
      </div>
    </div>
  </div>
);

// ────────────────────────────────────────────────────────
// RESULT — Mobile
// ────────────────────────────────────────────────────────
const QuestResultMobile = () => (
  <div className="q-mobile">
    <div style={{ position: 'relative', flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column' }}>
      <div style={{
        position: 'relative',
        padding: '40px 20px 24px',
        background: 'linear-gradient(180deg, #7F56D9, #53389E)',
        color: '#fff', textAlign: 'center', overflow: 'hidden'
      }}>
        <Confetti/>
        <div style={{ position: 'relative', zIndex: 1 }}>
          <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 8 }}>
            <Querymon size={110} wave/>
          </div>
          <div style={{
            display: 'inline-block', background: '#FAC515', color: '#1A0F3E',
            padding: '4px 12px', borderRadius: 999, fontSize: 11, fontWeight: 800,
            marginBottom: 8
          }}>⭐ JOIN 미션 완료</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 26, fontWeight: 800, lineHeight: 1.1 }}>
            잘했어요!
          </div>
          <div style={{ fontSize: 13, opacity: .9, marginTop: 6 }}>10문제 중 9문제 정답 · 90%</div>
          <div style={{ display: 'flex', justifyContent: 'center', gap: 6, marginTop: 12 }}>
            {[0,1,2].map(i => (
              <svg key={i} width="32" height="32" viewBox="0 0 48 48" fill="#FAC515" stroke="#1A0F3E" strokeWidth="2">
                <path d="m24 4 6 14 15 1.5-11 10.5 3 14.5L24 36l-13 8 3-14.5L3 19.5 18 18z"/>
              </svg>
            ))}
          </div>
        </div>
      </div>

      <div style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 12 }}>
        {/* Stats 2x2 */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
          {[
            { l: '획득 XP',  v: '+180',  c: '#FFB627' },
            { l: '획득 💎',  v: '+50',  c: '#F670C7' },
            { l: '정답률',   v: '90%',   c: '#7F56D9' },
            { l: '소요시간', v: '6:24',  c: '#12B76A' },
          ].map((x, i) => (
            <div key={i} style={{
              background: 'var(--q-surface)', border: '1px solid var(--q-border)',
              borderRadius: 14, padding: 12, textAlign: 'center'
            }}>
              <div style={{ fontSize: 10, color: 'var(--q-ink-3)', fontWeight: 700 }}>{x.l}</div>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 22, color: x.c, marginTop: 2 }}>{x.v}</div>
            </div>
          ))}
        </div>

        {/* Achievement */}
        <div className="q-achievement">
          <span className="emoji">🏆</span>
          <div className="body">
            <div className="ttl">새 도전과제!</div>
            <div className="sub">"JOIN 마스터" 획득</div>
          </div>
        </div>

        {/* Evolution */}
        <div className="q-mascot-evolve">
          <Querymon size={56}/>
          <div className="body">
            <div className="ttl">진화까지 320 XP</div>
            <div className="sub">다음: 🎓 학자 쿼리몬</div>
          </div>
        </div>

        {/* Review strip compact */}
        <div className="q-review-strip" style={{ padding: 14 }}>
          <div className="q-review-strip-title" style={{ fontSize: 12 }}>오답 1문제</div>
          <div className="q-review-row">
            <div className="q-review-num no">✕</div>
            <div className="q-review-q" style={{ fontSize: 12 }}>4. CROSS JOIN의 결과 행 수 계산 방법은?</div>
          </div>
        </div>
      </div>
    </div>

    <div style={{
      padding: '12px 16px 24px',
      background: 'var(--q-surface)', borderTop: '1px solid var(--q-border)',
      display: 'flex', gap: 8
    }}>
      <button style={{
        flex: '0 0 auto', padding: '12px 14px', borderRadius: 12,
        background: 'var(--q-surface-soft)', border: 0,
        color: 'var(--q-ink-2)', fontWeight: 700, fontSize: 13
      }}>오답 풀기</button>
      <button style={{
        flex: 1, padding: '12px', borderRadius: 12,
        background: '#7F56D9', color: '#fff', border: 0,
        fontWeight: 800, fontSize: 14, boxShadow: '0 3px 0 #53389E',
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 6
      }}><IPlay size={14}/> 다음 미션</button>
    </div>
  </div>
);

// ────────────────────────────────────────────────────────
// WRONG ANSWERS
// ────────────────────────────────────────────────────────
const QuestWrongDesktop = () => {
  const items = [
    { id: 41, ch: '2-1 · SQL 기본', cat: 'JOIN', diff: '상', q: 'CROSS JOIN의 결과 행 수는 어떻게 계산되는가? 두 테이블 EMP(14행)와 DEPT(4행)를 CROSS JOIN 했을 때 결과 행 수로 옳은 것은?', ago: '2시간 전', tries: 2 },
    { id: 38, ch: '1-2 · 데이터 모델과 성능', cat: '정규화', diff: '상', q: '제3정규형(3NF)을 만족하기 위한 조건으로 옳지 않은 것은? 모든 비식별자 속성은 주식별자에 완전 함수적 종속이어야 한다.', ago: '어제', tries: 3 },
    { id: 33, ch: '2-1 · SQL 기본', cat: 'GROUP BY', diff: '중', q: 'GROUP BY 절과 HAVING 절을 사용한 다음 SQL의 실행 순서로 옳은 것은?', ago: '어제', tries: 1 },
    { id: 27, ch: '2-2 · SQL 활용', cat: '서브쿼리', diff: '상', q: '중첩 서브쿼리와 인라인 뷰의 차이로 옳은 것은? 다음 중 두 가지 모두를 사용할 수 있는 상황은?', ago: '3일 전', tries: 4 },
    { id: 21, ch: '2-1 · SQL 기본', cat: 'NULL', diff: '하', q: 'NULL 값에 대한 비교 연산자 사용 시 결과로 옳은 것은? IS NULL과 = NULL의 차이는?', ago: '5일 전', tries: 1 },
  ];

  return (
    <div className="q q-canvas">
      <QuestTopbar current="quiz"/>
      <div className="q-main-narrow">
        <div className="q-page-header">
          <div>
            <h1>오답 다시 풀기</h1>
            <p>틀린 문제는 자동으로 모여요 — 한 번에 정복하면 보너스 보석을 받아요 💎</p>
          </div>
          <div className="q-tab-row">
            <div className="t on">오답 (12)</div>
            <div className="t">정복함 (28)</div>
            <div className="t">건너뜀 (3)</div>
          </div>
        </div>

        <div className="q-kpi-row">
          <div className="q-kpi"><div className="emoji">📕</div><div><div className="lbl">남은 오답</div><div className="val">12개</div></div></div>
          <div className="q-kpi"><div className="emoji">🎯</div><div><div className="lbl">재정복 성공</div><div className="val">28개</div></div></div>
          <div className="q-kpi"><div className="emoji">📈</div><div><div className="lbl">정복률</div><div className="val">70%</div></div></div>
          <div className="q-kpi"><div className="emoji">⚡</div><div><div className="lbl">연속 정복</div><div className="val">5일</div></div></div>
        </div>

        <div className="q-empty-cta">
          <Querymon size={70}/>
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 800, fontSize: 14, color: 'var(--q-ink)' }}>한 번에 12문제 다 풀어볼까요?</div>
            <div style={{ fontSize: 12, color: 'var(--q-ink-2)', marginTop: 2 }}>전부 정복하면 +200 💎 · +500 XP 보너스!</div>
          </div>
          <button style={{
            padding: '12px 20px', borderRadius: 12,
            background: '#7F56D9', color: '#fff', border: 0,
            fontWeight: 800, fontSize: 13, boxShadow: '0 4px 0 #53389E', cursor: 'pointer'
          }}>전체 도전 시작 →</button>
        </div>

        <div className="q-q-list">
          {items.map((x, i) => (
            <div key={i} className="q-q-card">
              <div className="num">#{x.id}</div>
              <div className="body">
                <div className="q-q-tags">
                  <span className="q-tag chapter">{x.ch}</span>
                  <span className="q-tag">{x.cat}</span>
                  <span className="q-tag hard">난이도 {x.diff}</span>
                  <span className="q-tag wrong">{x.tries}회 시도</span>
                </div>
                <div className="q-q-text">{x.q}</div>
                <div className="q-q-meta">
                  <span>마지막 오답 · {x.ago}</span>
                </div>
              </div>
              <div className="q-q-actions">
                <button className="q-q-btn primary">다시 풀기</button>
                <button className="q-q-btn ghost">해설 보기</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// ────────────────────────────────────────────────────────
// BOOKMARKS
// ────────────────────────────────────────────────────────
const QuestBookmarksDesktop = () => {
  const items = [
    { id: 88, ch: '2-1 · SQL 기본', cat: 'JOIN', q: 'SELF JOIN을 사용해 같은 테이블에서 상사-부하 관계를 조회하는 SQL로 옳은 것은?', note: '재귀 관계 패턴 기억하기', ago: '1시간 전' },
    { id: 75, ch: '2-3 · SQL 최적화', cat: '인덱스', q: '인덱스를 사용한 SQL이 더 느려질 수 있는 경우로 옳은 것은? 전체 데이터의 몇 % 이상 조회 시 풀스캔이 더 유리한가?', note: '20% 룰', ago: '어제' },
    { id: 64, ch: '1-1 · 데이터 모델링의 이해', cat: '식별자', q: '주식별자 후보 중 적절한 것을 선택하는 기준은?', note: '안정성 > 유일성 > 최소성', ago: '3일 전' },
    { id: 52, ch: '2-2 · SQL 활용', cat: '윈도우 함수', q: 'ROW_NUMBER, RANK, DENSE_RANK의 차이로 옳은 것은?', note: null, ago: '일주일 전' },
  ];

  return (
    <div className="q q-canvas">
      <QuestTopbar current="quiz"/>
      <div className="q-main-narrow">
        <div className="q-page-header">
          <div>
            <h1>북마크</h1>
            <p>다시 볼 문제를 모아둔 곳 · 노트도 함께 남겨두세요 📒</p>
          </div>
          <div className="q-tab-row">
            <div className="t on">모두 (24)</div>
            <div className="t">1과목 (8)</div>
            <div className="t">2과목 (16)</div>
            <div className="t">노트 있음 (11)</div>
          </div>
        </div>

        <div className="q-kpi-row" style={{ gridTemplateColumns: 'repeat(3, 1fr) 2fr' }}>
          <div className="q-kpi"><div className="emoji">🔖</div><div><div className="lbl">전체 북마크</div><div className="val">24개</div></div></div>
          <div className="q-kpi"><div className="emoji">📝</div><div><div className="lbl">노트 작성</div><div className="val">11개</div></div></div>
          <div className="q-kpi"><div className="emoji">🎯</div><div><div className="lbl">다시 풀기 성공</div><div className="val">9개</div></div></div>
          <div className="q-empty-cta" style={{ margin: 0, padding: '12px 16px' }}>
            <span style={{ fontSize: 24 }}>💡</span>
            <div style={{ flex: 1, fontSize: 12, color: 'var(--q-ink-2)', lineHeight: 1.45 }}>
              북마크 문제를 시험 1주 전에 모아 풀면 정답률이 평균 <b>+14%p</b> 오릅니다.
            </div>
          </div>
        </div>

        <div className="q-q-list">
          {items.map((x, i) => (
            <div key={i} className="q-q-card">
              <div className="num" style={{ color: '#FAC515', minWidth: 36 }}>
                <IBM size={18}/>
              </div>
              <div className="body">
                <div className="q-q-tags">
                  <span className="q-tag chapter">{x.ch}</span>
                  <span className="q-tag">{x.cat}</span>
                  {x.note && <span className="q-tag bookmark">노트 있음</span>}
                </div>
                <div className="q-q-text">{x.q}</div>
                {x.note && (
                  <div style={{
                    marginTop: 8, padding: '8px 12px',
                    background: 'rgba(250,197,21,.1)', borderRadius: 8,
                    fontSize: 12, color: 'var(--q-ink-2)', fontStyle: 'italic',
                    borderLeft: '3px solid #FAC515'
                  }}>
                    "{x.note}"
                  </div>
                )}
                <div className="q-q-meta">
                  <span>북마크 · {x.ago}</span>
                </div>
              </div>
              <div className="q-q-actions">
                <button className="q-q-btn primary">풀어보기</button>
                <button className="q-q-btn ghost">노트 수정</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

Object.assign(window, {
  QuestTopbar,
  QuestTheoryDesktop, QuestTheoryMobile,
  QuestResultDesktop, QuestResultMobile,
  QuestWrongDesktop, QuestBookmarksDesktop,
});
