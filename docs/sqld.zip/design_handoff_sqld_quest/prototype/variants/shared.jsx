/* eslint-disable */
/* Shared bits: icons + mascots used across variants */

// ───────── Icons (inline SVG, lightweight Lucide-style stroke=2) ─────────
const Icon = ({ d, size = 18, sw = 2 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round">
    {typeof d === 'string' ? <path d={d} /> : d}
  </svg>
);
const IFlame  = (p) => <Icon {...p} d={<><path d="M8.5 14.5A2.5 2.5 0 0 0 11 17c1.5 0 2.5-1.25 2.5-2.5 0-1.5-1-2-1.5-3.5-.5-1.5 0-3 1-4-3 0-7 3-7 7a5 5 0 0 0 5 5 5 5 0 0 0 5-5c0-2-1-3.5-2-4.5"/></>} />;
const IGem    = (p) => <Icon {...p} d={<><path d="M6 3h12l4 6-10 12L2 9Z"/><path d="M11 3 8 9l4 12 4-12-3-6"/><path d="M2 9h20"/></>} />;
const IHeart  = (p) => <Icon {...p} d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>;
const IHome   = (p) => <Icon {...p} d={<><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9,22 9,12 15,12 15,22"/></>} />;
const IBook   = (p) => <Icon {...p} d={<><path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"/></>} />;
const IPencil = (p) => <Icon {...p} d={<><path d="M17 3a2.85 2.85 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5z"/></>} />;
const ITarget = (p) => <Icon {...p} d={<><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></>} />;
const ITrophy = (p) => <Icon {...p} d={<><path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"/><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"/><path d="M4 22h16"/><path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22"/><path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"/><path d="M18 2H6v7a6 6 0 0 0 12 0V2Z"/></>} />;
const IBolt   = (p) => <Icon {...p} d="M13 2 3 14h9l-1 8 10-12h-9l1-8z"/>;
const IBM     = (p) => <Icon {...p} d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>;
const ICheck  = (p) => <Icon {...p} d="m5 12 5 5L20 7"/>;
const ILock   = (p) => <Icon {...p} d={<><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></>} />;
const IStar   = (p) => <Icon {...p} d="m12 2 3 7 7 .9-5.2 4.7L18.5 22 12 18 5.5 22 7.2 14.6 2 9.9 9 9z"/>;
const IChart  = (p) => <Icon {...p} d={<><path d="M3 3v18h18"/><path d="m7 14 4-4 3 3 5-6"/></>} />;
const ICal    = (p) => <Icon {...p} d={<><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></>} />;
const IClock  = (p) => <Icon {...p} d={<><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></>} />;
const ISword  = (p) => <Icon {...p} d={<><path d="m14.5 17.5 4-4-12-12H3v3.5l12 12z"/><path d="m9.5 14 3 3"/><path d="M13 19l6 6 4-4-6-6"/></>} />;
const IShield = (p) => <Icon {...p} d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>;
const IPlus   = (p) => <Icon {...p} d="M12 5v14M5 12h14"/>;
const IUp     = (p) => <Icon {...p} d={<><path d="m6 9 6-6 6 6"/><path d="M12 3v18"/></>} />;
const IDn     = (p) => <Icon {...p} d="m6 9 6 6 6-6"/>;
const IPlay   = (p) => <Icon {...p} d={<><polygon points="6,3 21,12 6,21" fill="currentColor" stroke="none"/></>} />;
const IFire2  = (p) => IFlame(p);
const IRefresh= (p) => <Icon {...p} d={<><path d="M3 12a9 9 0 1 0 9-9c-2.4 0-4.7 1-6.4 2.6L3 8"/><path d="M3 3v5h5"/></>} />;

// ───────── Mascots ─────────
// Querymon — friendly database character (Variant A)
const Querymon = ({ size = 200, mood = 'happy', wave = false }) => (
  <svg width={size} height={size * 1.05} viewBox="0 0 200 210">
    <defs>
      <linearGradient id="qbody" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#9B8AFB"/>
        <stop offset="1" stopColor="#6941C6"/>
      </linearGradient>
      <linearGradient id="qhi" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#FFFFFF" stopOpacity=".5"/>
        <stop offset="1" stopColor="#FFFFFF" stopOpacity="0"/>
      </linearGradient>
    </defs>
    {/* Shadow */}
    <ellipse cx="100" cy="195" rx="55" ry="8" fill="#000" opacity=".12"/>
    {/* Crown */}
    <path d="M70 30 L80 50 L92 26 L100 48 L108 26 L120 50 L130 30 L128 56 L72 56 Z"
          fill="#FAC515" stroke="#A15C07" strokeWidth="2" strokeLinejoin="round"/>
    <circle cx="80" cy="32" r="3" fill="#FF6B6B"/>
    <circle cx="120" cy="32" r="3" fill="#84CAFF"/>
    <circle cx="100" cy="26" r="3" fill="#12B76A"/>
    {/* Body — DB cylinder stack */}
    <g>
      {/* bottom disk */}
      <ellipse cx="100" cy="170" rx="56" ry="14" fill="url(#qbody)"/>
      <path d="M44 130 L44 170 A56 14 0 0 0 156 170 L156 130 Z" fill="url(#qbody)"/>
      <ellipse cx="100" cy="130" rx="56" ry="14" fill="#7F56D9"/>
      {/* mid disk */}
      <path d="M48 100 L48 130 A52 13 0 0 0 152 130 L152 100 Z" fill="url(#qbody)"/>
      <ellipse cx="100" cy="100" rx="52" ry="13" fill="#7F56D9"/>
      {/* top disk = head */}
      <path d="M52 72 L52 100 A48 12 0 0 0 148 100 L148 72 Z" fill="url(#qbody)"/>
      <ellipse cx="100" cy="72" rx="48" ry="12" fill="#9B8AFB"/>
      {/* highlight strip */}
      <path d="M58 80 Q60 95 64 110 L60 130 Q60 130 64 130 Q66 100 70 80 Z" fill="url(#qhi)"/>
    </g>
    {/* Face on top disk */}
    <g>
      <circle cx="84" cy="86" r="5" fill="#1A0F3E"/>
      <circle cx="116" cy="86" r="5" fill="#1A0F3E"/>
      <circle cx="82" cy="84" r="1.5" fill="#fff"/>
      <circle cx="114" cy="84" r="1.5" fill="#fff"/>
      <ellipse cx="74" cy="94" rx="4" ry="2" fill="#F670C7" opacity=".6"/>
      <ellipse cx="126" cy="94" rx="4" ry="2" fill="#F670C7" opacity=".6"/>
      {mood === 'happy' ? (
        <path d="M90 96 Q100 104 110 96" stroke="#1A0F3E" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
      ) : (
        <circle cx="100" cy="98" r="3" fill="#1A0F3E"/>
      )}
    </g>
    {/* Arm waving */}
    {wave && (
      <g>
        <path d="M44 110 Q30 100 26 80" stroke="#6941C6" strokeWidth="10" strokeLinecap="round" fill="none"/>
        <circle cx="26" cy="78" r="9" fill="#9B8AFB" stroke="#6941C6" strokeWidth="2"/>
      </g>
    )}
  </svg>
);

// Owl coach (Variant B) — minimal geometric
const OwlCoach = ({ size = 88 }) => (
  <svg width={size} height={size} viewBox="0 0 88 88">
    <defs>
      <linearGradient id="owlbg" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stopColor="#F670C7"/>
        <stop offset="1" stopColor="#6941C6"/>
      </linearGradient>
    </defs>
    <rect x="0" y="0" width="88" height="88" rx="20" fill="url(#owlbg)"/>
    {/* Body */}
    <g transform="translate(14, 12)">
      <ellipse cx="30" cy="36" rx="26" ry="28" fill="#101828"/>
      {/* Eyes */}
      <circle cx="20" cy="30" r="11" fill="#FAFAFF"/>
      <circle cx="40" cy="30" r="11" fill="#FAFAFF"/>
      <circle cx="20" cy="30" r="5" fill="#101828"/>
      <circle cx="40" cy="30" r="5" fill="#101828"/>
      <circle cx="22" cy="28" r="1.6" fill="#fff"/>
      <circle cx="42" cy="28" r="1.6" fill="#fff"/>
      {/* Beak */}
      <path d="M30 38 L26 46 L34 46 Z" fill="#FAC515"/>
      {/* Tufts */}
      <path d="M8 14 L14 24 L18 14 Z" fill="#101828"/>
      <path d="M42 14 L46 24 L52 14 Z" fill="#101828"/>
      {/* Glasses bridge */}
      <path d="M28 30 L32 30" stroke="#FAFAFF" strokeWidth="1.5"/>
    </g>
  </svg>
);

// Knight avatar (Variant C) — pixel-ish
const KnightAvatar = ({ size = 128 }) => (
  <svg width={size} height={size} viewBox="0 0 64 64" shapeRendering="crispEdges">
    {/* Pixel grid 16×16 */}
    {(() => {
      // 0=empty, 1=outline, 2=skin/body, 3=helmet (gold), 4=highlight, 5=eye, 6=cape/red
      const P = [
        "................",
        "....111111......",
        "...13333331.....",
        "..1333344431....",
        "..1334444431....",
        "..133111133341..",
        "..133553553341..",
        ".1333553553341..",
        ".13333313333341.",
        ".13333333333341.",
        ".11333333333311.",
        "...122222221....",
        "..12266666221...",
        "..12266666221...",
        ".1222266662221..",
        ".1222266662221..",
      ];
      const C = { '1':'#1A0F3E','2':'#F4F3FF','3':'#FAC515','4':'#FDE272','5':'#101828','6':'#F97066','.':null };
      const out = [];
      for (let y = 0; y < P.length; y++)
        for (let x = 0; x < P[y].length; x++) {
          const c = C[P[y][x]];
          if (c) out.push(<rect key={y+'_'+x} x={x*4} y={y*4} width="4" height="4" fill={c}/>);
        }
      return out;
    })()}
  </svg>
);

// Activity ring (Variant B) — multi-arc concentric
const ActivityRings = ({ size = 200, rings = [{ pct: .72, color: '#F670C7' }, { pct: .56, color: '#FAC515' }, { pct: .9, color: '#12B76A' }] }) => {
  const cx = size/2, cy = size/2;
  const stroke = size * 0.085;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      {rings.map((r, i) => {
        const radius = size/2 - stroke/2 - i * (stroke + 4) - 4;
        const c = 2 * Math.PI * radius;
        return (
          <g key={i}>
            <circle cx={cx} cy={cy} r={radius} fill="none" stroke={r.color} strokeOpacity=".18" strokeWidth={stroke}/>
            <circle cx={cx} cy={cy} r={radius} fill="none" stroke={r.color} strokeWidth={stroke}
              strokeLinecap="round"
              strokeDasharray={`${c * r.pct} ${c}`} transform={`rotate(-90 ${cx} ${cy})`}/>
          </g>
        );
      })}
    </svg>
  );
};

// Radar chart (Variant B)
const Radar = ({ size = 240, values = [70, 85, 60, 78, 92], labels = ['데이터모델링', 'SQL 기본', 'SQL 활용', '최적화', '문제풀이'] }) => {
  const cx = size / 2, cy = size / 2, R = size * 0.36;
  const n = values.length;
  const pts = values.map((v, i) => {
    const a = -Math.PI / 2 + (2 * Math.PI / n) * i;
    const r = R * (v / 100);
    return [cx + r * Math.cos(a), cy + r * Math.sin(a)];
  });
  const grid = [0.25, 0.5, 0.75, 1].map(f => {
    return Array.from({ length: n }).map((_, i) => {
      const a = -Math.PI/2 + (2*Math.PI/n) * i;
      return `${cx + R*f*Math.cos(a)},${cy + R*f*Math.sin(a)}`;
    }).join(' ');
  });
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      {grid.map((g, i) => <polygon key={i} points={g} fill="none" stroke="#EAECF0" strokeWidth="1"/>)}
      {Array.from({ length: n }).map((_, i) => {
        const a = -Math.PI/2 + (2*Math.PI/n) * i;
        return <line key={i} x1={cx} y1={cy} x2={cx + R*Math.cos(a)} y2={cy + R*Math.sin(a)} stroke="#EAECF0"/>;
      })}
      <polygon points={pts.map(p => p.join(',')).join(' ')} fill="#7F56D9" fillOpacity=".18" stroke="#7F56D9" strokeWidth="2"/>
      {pts.map((p, i) => <circle key={i} cx={p[0]} cy={p[1]} r="4" fill="#7F56D9"/>)}
      {labels.map((l, i) => {
        const a = -Math.PI/2 + (2*Math.PI/n) * i;
        const lr = R + 18;
        return (
          <text key={i} x={cx + lr*Math.cos(a)} y={cy + lr*Math.sin(a)}
            textAnchor="middle" dominantBaseline="middle"
            fontSize="11" fontWeight="600" fill="#475467" fontFamily="Noto Sans KR">
            {l}
          </text>
        );
      })}
    </svg>
  );
};

// Sparkline
const Sparkline = ({ data = [40, 55, 50, 62, 70, 68, 80, 76, 88, 92], color = '#7F56D9', w = 200, h = 60 }) => {
  const max = Math.max(...data), min = Math.min(...data);
  const span = max - min || 1;
  const step = w / (data.length - 1);
  const pts = data.map((v, i) => [i * step, h - 6 - ((v - min) / span) * (h - 12)]);
  const d = 'M ' + pts.map(p => p.join(' ')).join(' L ');
  return (
    <svg viewBox={`0 0 ${w} ${h}`} width="100%" height={h}>
      <defs>
        <linearGradient id={`sp-${color.slice(1)}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={color} stopOpacity=".25"/>
          <stop offset="1" stopColor={color} stopOpacity="0"/>
        </linearGradient>
      </defs>
      <path d={`${d} L ${w} ${h} L 0 ${h} Z`} fill={`url(#sp-${color.slice(1)})`}/>
      <path d={d} fill="none" stroke={color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
      <circle cx={pts[pts.length-1][0]} cy={pts[pts.length-1][1]} r="4" fill={color}/>
      <circle cx={pts[pts.length-1][0]} cy={pts[pts.length-1][1]} r="8" fill={color} opacity=".2"/>
    </svg>
  );
};

// Heatmap data (12 weeks × 7 days) — deterministic pattern
const heatmapData = (() => {
  const out = [];
  let seed = 7;
  for (let i = 0; i < 12*7; i++) {
    seed = (seed * 1103515245 + 12345) & 0x7fffffff;
    const r = seed / 0x7fffffff;
    // Recent days busier
    const recency = i / (12*7);
    const v = r * 0.6 + recency * 0.6;
    out.push(v > 0.9 ? 5 : v > 0.7 ? 4 : v > 0.5 ? 3 : v > 0.3 ? 2 : v > 0.15 ? 1 : 0);
  }
  return out;
})();

Object.assign(window, {
  Icon, IFlame, IGem, IHeart, IHome, IBook, IPencil, ITarget, ITrophy,
  IBolt, IBM, ICheck, ILock, IStar, IChart, ICal, IClock, ISword, IShield,
  IPlus, IUp, IDn, IPlay, IRefresh,
  Querymon, OwlCoach, KnightAvatar, ActivityRings, Radar, Sparkline,
  heatmapData,
});
