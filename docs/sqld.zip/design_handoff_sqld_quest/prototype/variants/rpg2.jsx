/* eslint-disable */
/* Variant C — "Boss Raid" (RPG-style) */

const RpgDesktop = () => (
  <div className="r r-canvas">
    <div className="r-topbar">
      <div className="r-brand">
        <div className="r-brand-mark"/>
        SQLD <span style={{ color: '#FAC515' }}>RAID</span>
      </div>
      <nav className="r-nav">
        <a className="on">던전</a>
        <a>퀘스트</a>
        <a>장비</a>
        <a>랭킹</a>
        <a>도감</a>
      </nav>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <span className="r-coin"><IGem size={14}/> 1,420</span>
        <span style={{
          display: 'inline-flex', alignItems: 'center', gap: 6,
          padding: '6px 12px', borderRadius: 999,
          background: 'rgba(249,112,102,.15)', color: '#FDA29B',
          border: '1px solid rgba(249,112,102,.3)',
          fontWeight: 800, fontSize: 13, fontFamily: 'var(--font-mono)'
        }}><IFlame size={14}/> 14일 연속</span>
        <button style={{
          width: 36, height: 36, borderRadius: 50, background: 'var(--r-gold)',
          color: '#1A0F3E', border: 0, fontWeight: 800, fontSize: 13
        }}>JS</button>
      </div>
    </div>

    <div className="r-grid">
      {/* LEFT: Character */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        <div className="r-panel">
          <div className="r-panel-title">CHARACTER · LV. 12</div>
          <div className="r-char">
            <div className="r-char-avatar">
              <KnightAvatar size={128}/>
              <div style={{
                position: 'absolute', bottom: -6, right: -6,
                background: '#1A0F3E', color: '#FAC515',
                fontFamily: 'var(--font-mono)', fontWeight: 800,
                fontSize: 12, padding: '4px 8px', borderRadius: 999,
                border: '2px solid #FAC515'
              }}>LV.12</div>
            </div>
            <div style={{ textAlign: 'center' }}>
              <div className="r-char-name">진수 / DB 견습기사</div>
              <div className="r-char-class">SQL Apprentice · 2-tier</div>
            </div>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 14, marginTop: 8 }}>
            <div className="r-bar">
              <div className="r-bar-lbl"><span>HP · 집중력</span><span className="r-bar-val">82 / 100</span></div>
              <div className="r-bar-track"><div className="r-bar-fill hp" style={{ width: '82%' }}/></div>
            </div>
            <div className="r-bar">
              <div className="r-bar-lbl"><span>MP · 학습량</span><span className="r-bar-val">54 / 100</span></div>
              <div className="r-bar-track"><div className="r-bar-fill mp" style={{ width: '54%' }}/></div>
            </div>
            <div className="r-bar">
              <div className="r-bar-lbl"><span>EXP · 다음 레벨까지</span><span className="r-bar-val">3,240 / 5,000</span></div>
              <div className="r-bar-track"><div className="r-bar-fill xp" style={{ width: '64%' }}/></div>
            </div>
          </div>
        </div>

        <div className="r-panel">
          <div className="r-panel-title">스탯 / SKILL TREE</div>
          <div className="r-stats">
            <div className="r-stat">
              <div className="lbl">⚔ 공격력</div>
              <div className="val">82 <small>+12</small></div>
            </div>
            <div className="r-stat">
              <div className="lbl">🛡 방어력</div>
              <div className="val">64 <small>+5</small></div>
            </div>
            <div className="r-stat">
              <div className="lbl">⚡ 속도</div>
              <div className="val">42s <small>/문제</small></div>
            </div>
            <div className="r-stat">
              <div className="lbl">🍀 운</div>
              <div className="val">+18% <small>크리티컬</small></div>
            </div>
          </div>
          <div style={{ marginTop: 12, fontSize: 11, color: 'var(--r-ink-dim)', fontFamily: 'var(--font-mono)' }}>
            ⚔ 정답률 → 공격력 변환 · 🛡 오답복습률 → 방어력
          </div>
        </div>

        <div className="r-panel" style={{ background: 'linear-gradient(180deg, rgba(250,197,21,.18), rgba(250,197,21,0.04))', borderColor: 'rgba(250,197,21,.3)' }}>
          <div className="r-panel-title" style={{ color: '#FDE272' }}>장착 장비 · GEAR</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8 }}>
            {[
              { i: '⚔', n: 'SELECT 검', t: '+12' },
              { i: '🛡', n: 'JOIN 방패', t: '+8' },
              { i: '📜', n: 'WHERE 룬', t: '+5' },
              { i: '💍', n: '인덱스 반지', t: '+3' },
            ].map((x, i) => (
              <div key={i} style={{
                aspectRatio: '1/1.05', borderRadius: 10,
                background: 'rgba(0,0,0,.3)', border: '1px solid rgba(250,197,21,.3)',
                display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
                position: 'relative', padding: 4
              }}>
                <div style={{ fontSize: 22 }}>{x.i}</div>
                <div style={{ fontSize: 9, color: '#FDE272', fontWeight: 600, marginTop: 4, textAlign: 'center' }}>{x.n}</div>
                <div style={{
                  position: 'absolute', top: 4, right: 4,
                  fontFamily: 'var(--font-mono)', fontSize: 9, fontWeight: 800,
                  color: '#FAC515'
                }}>{x.t}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* MID: Dungeon map + Boss */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        <div className="r-panel" style={{ padding: 0 }}>
          <div style={{ padding: '20px 20px 0' }}>
            <div className="r-panel-title">WORLD MAP · 5개 던전</div>
          </div>
          <div style={{ padding: '4px 20px 20px' }} className="r-dungeons">
            {[
              { n: '데이터 모델링의 이해',    rate: '88%', meta: '18문항 클리어', diff: 1, state: 'cleared', icon: '🗂️' },
              { n: '데이터 모델과 성능',       rate: '82%', meta: '22문항 클리어', diff: 2, state: 'cleared', icon: '⚙️' },
              { n: 'SQL 기본의 숲',           rate: '78%', meta: '18 / 28 진행 중', diff: 3, state: 'current', icon: '🌲' },
              { n: 'SQL 활용의 동굴',          rate: '—',   meta: '잠김 · LV.13 필요',  diff: 4, state: 'locked', icon: '🕳️' },
              { n: 'SQL 최적화 신전',          rate: '—',   meta: '잠김 · LV.15 필요',  diff: 5, state: 'locked', icon: '🏛️' },
            ].map((x, i) => (
              <div key={i} className={`r-dungeon ${x.state}`}>
                <div className="r-dungeon-icon">{x.icon}</div>
                <div className="r-dungeon-body">
                  <div className="r-dungeon-name">{x.n}</div>
                  <div className="r-dungeon-meta">
                    <span>{x.meta}</span>
                    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                      난이도
                      <span className="r-diff">
                        {[1,2,3,4,5].map(s => <span key={s} className={`s ${s > x.diff ? 'off' : ''}`}/>)}
                      </span>
                    </span>
                  </div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--r-ink-dim)', fontWeight: 700, letterSpacing: '.08em' }}>CLEAR</div>
                  <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 18, color: x.state === 'locked' ? 'var(--r-ink-dim)' : '#fff' }}>{x.rate}</div>
                </div>
                {x.state === 'current' && (
                  <button style={{
                    padding: '8px 14px', borderRadius: 8, background: 'var(--r-gold)', color: '#1A0F3E',
                    border: 0, fontWeight: 800, fontSize: 12, fontFamily: 'var(--font-mono)', textTransform: 'uppercase', letterSpacing: '.06em'
                  }}>입장</button>
                )}
                {x.state === 'cleared' && (
                  <button style={{
                    padding: '8px 14px', borderRadius: 8, background: 'rgba(255,255,255,.08)', color: '#fff',
                    border: '1px solid rgba(255,255,255,.15)', fontWeight: 700, fontSize: 12, fontFamily: 'var(--font-mono)', textTransform: 'uppercase', letterSpacing: '.06em'
                  }}>재도전</button>
                )}
                {x.state === 'locked' && (
                  <div style={{ color: 'var(--r-ink-dim)' }}><ILock size={18}/></div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Boss banner */}
        <div className="r-boss">
          <div style={{ display: 'flex', alignItems: 'center', gap: 24 }}>
            <div style={{
              width: 96, height: 96, borderRadius: 22,
              background: 'radial-gradient(circle at 30% 30%, #FCA5E5, #BE185D 70%, #581C87)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 56, boxShadow: '0 0 32px rgba(247,112,199,.5)',
              flexShrink: 0
            }}>👑</div>
            <div style={{ flex: 1 }}>
              <span className="r-boss-tag">FINAL BOSS · D-23</span>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 24, lineHeight: 1.1, marginBottom: 4 }}>
                실전 모의고사 — 50문항 / 90분
              </div>
              <div style={{ fontSize: 13, color: 'var(--r-ink-dim)' }}>
                권장 LV.15 이상 · 보스 격파 시 <span style={{ color: '#FAC515', fontWeight: 700 }}>+1,200 EXP · 합격 휘장</span>
              </div>

              {/* Boss HP bar */}
              <div className="r-bar" style={{ marginTop: 14 }}>
                <div className="r-bar-lbl"><span style={{ color: '#FDA29B' }}>BOSS HP · 합격선 60문항</span><span className="r-bar-val">100%</span></div>
                <div className="r-bar-track"><div className="r-bar-fill hp" style={{ width: '100%' }}/></div>
              </div>
            </div>
            <button style={{
              padding: '14px 28px', borderRadius: 12, background: '#FAC515', color: '#1A0F3E',
              border: 0, fontWeight: 900, fontSize: 14, fontFamily: 'var(--font-mono)', textTransform: 'uppercase', letterSpacing: '.06em',
              boxShadow: '0 8px 24px rgba(250,197,21,.4)', cursor: 'pointer', alignSelf: 'flex-end'
            }}>도전!</button>
          </div>
        </div>
      </div>

      {/* RIGHT: Daily quests + leaderboard */}
      <aside style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        <div className="r-panel">
          <div className="r-panel-title">DAILY QUEST <span style={{ fontFamily: 'var(--font-mono)', color: '#FAC515' }}>2/4</span></div>
          <div>
            {[
              { t: '5문제 풀기',        cur: 5, max: 5, rwd: 50,  done: true },
              { t: 'JOIN 3문제 정답',   cur: 3, max: 3, rwd: 80,  done: true },
              { t: '오답 노트 풀기',     cur: 2, max: 5, rwd: 100, done: false, now: true },
              { t: '이론 1챕터 완독',    cur: 0, max: 1, rwd: 150, done: false },
            ].map((q, i) => (
              <div key={i} className="r-quest" style={{ opacity: q.done ? .65 : 1, borderColor: q.now ? 'rgba(250,197,21,.4)' : undefined }}>
                <div className="r-quest-head">
                  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}>
                    {q.done ? (
                      <span style={{ width: 14, height: 14, background: '#32D583', borderRadius: 4, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', color: '#054F31' }}><ICheck size={10}/></span>
                    ) : (
                      <span style={{ width: 14, height: 14, border: '2px solid #FAC515', borderRadius: 4 }}/>
                    )}
                    {q.t}
                  </span>
                  <span className="r-quest-reward">+{q.rwd} ◆</span>
                </div>
                <div className="r-quest-prog">
                  <div className="r-quest-prog-fill" style={{ width: `${(q.cur/q.max)*100}%`, background: q.done ? '#32D583' : '#FAC515' }}/>
                </div>
                <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 4, fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--r-ink-dim)' }}>
                  {q.cur} / {q.max}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="r-panel">
          <div className="r-panel-title">PARTY 랭킹 <span style={{ fontFamily: 'var(--font-mono)', color: 'var(--r-ink-dim)' }}>실버 리그</span></div>
          {[
            { r: 1, n: '데이터요정',  xp: 18420, you: false, badge: '🥇' },
            { r: 2, n: '쿼리장인',     xp: 16210, you: false, badge: '🥈' },
            { r: 3, n: '인덱스왕',     xp: 14800, you: false, badge: '🥉' },
            { r: 12, n: '진수 (나)',    xp: 12480, you: true,  badge: null },
          ].map((p, i) => (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', gap: 10,
              padding: '10px 0',
              borderBottom: i < 3 ? '1px dashed rgba(189,180,254,.15)' : 0,
              background: p.you ? 'linear-gradient(90deg, rgba(250,197,21,.12), transparent)' : 'transparent',
              borderRadius: p.you ? 8 : 0,
              paddingLeft: p.you ? 12 : 0,
              marginLeft: p.you ? -12 : 0,
              marginRight: p.you ? -12 : 0,
              paddingRight: p.you ? 12 : 0
            }}>
              <span style={{
                width: 28, fontFamily: 'var(--font-mono)', fontWeight: 800, fontSize: 13,
                color: p.you ? '#FAC515' : 'var(--r-ink-dim)'
              }}>{p.badge || `#${p.r}`}</span>
              <span style={{ flex: 1, fontWeight: 600, fontSize: 13, color: p.you ? '#FAC515' : '#fff' }}>{p.n}</span>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--r-ink-dim)', fontWeight: 600 }}>{p.xp.toLocaleString()} XP</span>
            </div>
          ))}
        </div>

        <div className="r-panel" style={{ background: 'linear-gradient(180deg, rgba(50,213,131,.15), rgba(50,213,131,.02))', borderColor: 'rgba(50,213,131,.3)' }}>
          <div className="r-panel-title" style={{ color: '#6CE9A6' }}>최근 획득 · ACHIEVEMENTS</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8 }}>
            {['🔥','💎','⚔️','🎯','📚','🏃'].map((e, i) => (
              <div key={i} style={{
                aspectRatio: '1/1', borderRadius: 10,
                background: i < 3 ? 'rgba(50,213,131,.15)' : 'rgba(0,0,0,.3)',
                border: `1px solid ${i < 3 ? 'rgba(50,213,131,.4)' : 'rgba(189,180,254,.1)'}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 20, opacity: i < 3 ? 1 : .4,
                filter: i < 3 ? 'none' : 'grayscale(1)'
              }}>{e}</div>
            ))}
          </div>
        </div>
      </aside>
    </div>
  </div>
);

// ── Mobile ─────────────────────────────────────────────────
const RpgMobile = () => (
  <div className="r-mobile">
    <div className="r-mobile-top">
      <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 18, color: '#fff', display: 'flex', alignItems: 'center', gap: 8 }}>
        <div style={{
          width: 26, height: 26, background: 'var(--r-gold)',
          clipPath: 'polygon(50% 0%, 100% 38%, 82% 100%, 18% 100%, 0% 38%)',
        }}/>
        SQLD <span style={{ color: '#FAC515' }}>RAID</span>
      </div>
      <div style={{ marginLeft: 'auto', display: 'flex', gap: 6 }}>
        <span style={{
          display: 'inline-flex', alignItems: 'center', gap: 4,
          padding: '4px 10px', borderRadius: 999,
          background: 'rgba(250,197,21,.15)', color: '#FAC515',
          border: '1px solid rgba(250,197,21,.3)',
          fontWeight: 800, fontSize: 11, fontFamily: 'var(--font-mono)'
        }}><IGem size={11}/> 1.4k</span>
      </div>
    </div>

    <div className="r-mobile-body">
      {/* Character card */}
      <div className="r-panel" style={{ padding: 14, marginBottom: 14 }}>
        <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
          <div style={{
            width: 72, height: 72, borderRadius: 16,
            background: 'radial-gradient(circle at 30% 30%, rgba(255,255,255,.3), transparent 50%), linear-gradient(135deg, #FAC515, #F97066)',
            display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative', flexShrink: 0,
            boxShadow: '0 6px 16px rgba(250,197,21,.4)'
          }}>
            <KnightAvatar size={72}/>
            <div style={{
              position: 'absolute', bottom: -4, right: -4,
              background: '#1A0F3E', color: '#FAC515',
              fontFamily: 'var(--font-mono)', fontWeight: 800,
              fontSize: 10, padding: '2px 6px', borderRadius: 999,
              border: '2px solid #FAC515'
            }}>12</div>
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 16, fontWeight: 800, color: '#fff' }}>진수 / DB 견습기사</div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: '#FAC515', textTransform: 'uppercase', letterSpacing: '.08em', fontWeight: 700, marginTop: 2 }}>SQL Apprentice</div>
            <div className="r-bar" style={{ marginTop: 8 }}>
              <div className="r-bar-lbl" style={{ fontSize: 9 }}>
                <span>EXP</span><span className="r-bar-val" style={{ fontSize: 10 }}>3,240 / 5,000</span>
              </div>
              <div className="r-bar-track" style={{ height: 8 }}><div className="r-bar-fill xp" style={{ width: '64%' }}/></div>
            </div>
          </div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6, marginTop: 12 }}>
          <div className="r-bar">
            <div className="r-bar-lbl" style={{ fontSize: 9 }}><span style={{ color: '#FDA29B' }}>HP</span><span className="r-bar-val" style={{ fontSize: 10 }}>82</span></div>
            <div className="r-bar-track" style={{ height: 8 }}><div className="r-bar-fill hp" style={{ width: '82%' }}/></div>
          </div>
          <div className="r-bar">
            <div className="r-bar-lbl" style={{ fontSize: 9 }}><span style={{ color: '#84CAFF' }}>MP</span><span className="r-bar-val" style={{ fontSize: 10 }}>54</span></div>
            <div className="r-bar-track" style={{ height: 8 }}><div className="r-bar-fill mp" style={{ width: '54%' }}/></div>
          </div>
        </div>
      </div>

      {/* Boss banner */}
      <div className="r-boss" style={{ padding: 16, marginBottom: 14 }}>
        <span className="r-boss-tag">FINAL BOSS · D-23</span>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{
            width: 56, height: 56, borderRadius: 14,
            background: 'radial-gradient(circle at 30% 30%, #FCA5E5, #BE185D 70%)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 30, flexShrink: 0
          }}>👑</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 15, lineHeight: 1.2 }}>실전 모의고사</div>
            <div style={{ fontSize: 11, color: 'var(--r-ink-dim)', marginTop: 2 }}>50문항 / 90분 · 합격선 60</div>
          </div>
          <button style={{
            padding: '8px 14px', borderRadius: 8, background: '#FAC515', color: '#1A0F3E',
            border: 0, fontWeight: 800, fontSize: 11, fontFamily: 'var(--font-mono)', textTransform: 'uppercase', letterSpacing: '.06em',
          }}>도전!</button>
        </div>
      </div>

      {/* Dungeon list */}
      <div className="r-panel" style={{ padding: 14, marginBottom: 14 }}>
        <div className="r-panel-title" style={{ marginBottom: 10 }}>월드맵 · 5개 던전</div>
        <div className="r-dungeons">
          {[
            { n: '데이터 모델링', meta: 'CLEAR · 88%', diff: 1, state: 'cleared', icon: '🗂️' },
            { n: 'SQL 기본의 숲', meta: '진행 중 · 18/28', diff: 3, state: 'current', icon: '🌲' },
            { n: 'SQL 활용 동굴', meta: 'LV.13 필요', diff: 4, state: 'locked', icon: '🕳️' },
          ].map((x, i) => (
            <div key={i} className={`r-dungeon ${x.state}`} style={{ padding: 12 }}>
              <div className="r-dungeon-icon" style={{ width: 40, height: 40, fontSize: 18 }}>{x.icon}</div>
              <div className="r-dungeon-body">
                <div className="r-dungeon-name" style={{ fontSize: 13 }}>{x.n}</div>
                <div className="r-dungeon-meta" style={{ fontSize: 9 }}>{x.meta}</div>
              </div>
              <span className="r-diff" style={{ marginLeft: 'auto' }}>
                {[1,2,3,4,5].map(s => <span key={s} className={`s ${s > x.diff ? 'off' : ''}`} style={{ width: 8, height: 8 }}/>)}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Daily quests */}
      <div className="r-panel" style={{ padding: 14 }}>
        <div className="r-panel-title" style={{ marginBottom: 10 }}>DAILY QUEST <span style={{ fontFamily: 'var(--font-mono)', color: '#FAC515' }}>2/4</span></div>
        {[
          { t: '5문제 풀기',   cur: 5, max: 5, rwd: 50, done: true },
          { t: '오답 노트 풀기', cur: 2, max: 5, rwd: 100 },
        ].map((q, i) => (
          <div key={i} className="r-quest" style={{ padding: 10, opacity: q.done ? .65 : 1 }}>
            <div className="r-quest-head" style={{ fontSize: 12 }}>
              <span>{q.t}</span>
              <span className="r-quest-reward">+{q.rwd} ◆</span>
            </div>
            <div className="r-quest-prog" style={{ height: 5 }}>
              <div className="r-quest-prog-fill" style={{ width: `${(q.cur/q.max)*100}%`, background: q.done ? '#32D583' : '#FAC515' }}/>
            </div>
          </div>
        ))}
      </div>
    </div>

    {/* Bottom nav */}
    <div style={{
      position: 'absolute', bottom: 0, left: 0, right: 0,
      background: 'rgba(26,15,62,.95)', backdropFilter: 'blur(8px)',
      borderTop: '1px solid rgba(189,180,254,.16)',
      display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)',
      padding: '10px 8px 24px'
    }}>
      {[
        { i: <ISword size={20}/>, l: '던전', on: true },
        { i: <ITarget size={20}/>, l: '퀘스트' },
        { i: <IShield size={20}/>, l: '장비' },
        { i: <ITrophy size={20}/>, l: '랭킹' },
        { i: <IBook size={20}/>, l: '도감' },
      ].map((x, i) => (
        <a key={i} style={{
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
          fontSize: 10, fontWeight: 700, color: x.on ? '#FAC515' : 'var(--r-ink-dim)',
          fontFamily: 'var(--font-mono)', textTransform: 'uppercase', letterSpacing: '.04em'
        }}>{x.i}<span>{x.l}</span></a>
      ))}
    </div>
  </div>
);

// ── Boss battle / Mock exam in progress ──────────────────────
const RpgBossBattle = () => (
  <div className="r-mobile" style={{
    background: 'radial-gradient(ellipse 100% 60% at 50% 0%, rgba(247,112,199,.4), transparent 60%), radial-gradient(ellipse 80% 40% at 50% 100%, rgba(249,112,102,.3), transparent 60%), #1A0F3E'
  }}>
    {/* Boss header */}
    <div style={{ padding: '14px 16px' }}>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12
      }}>
        <button style={{ width: 32, height: 32, borderRadius: 8, background: 'rgba(255,255,255,.1)', color: '#fff', border: 0 }}>×</button>
        <span style={{
          fontFamily: 'var(--font-mono)', fontSize: 10, fontWeight: 800,
          letterSpacing: '.08em', textTransform: 'uppercase',
          padding: '4px 10px', borderRadius: 4,
          background: 'rgba(249,112,102,.2)', color: '#FDA29B',
          border: '1px solid rgba(249,112,102,.4)'
        }}>BOSS FIGHT</span>
        <span style={{ marginLeft: 'auto', fontFamily: 'var(--font-mono)', fontSize: 13, fontWeight: 800, color: '#FAC515' }}>
          <IClock size={12} style={{ verticalAlign: 'middle' }}/> 73:42
        </span>
      </div>

      {/* Boss avatar + HP */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 14, padding: 14,
        borderRadius: 14,
        background: 'rgba(0,0,0,.3)',
        border: '1px solid rgba(247,112,199,.3)'
      }}>
        <div style={{
          width: 64, height: 64, borderRadius: 16,
          background: 'radial-gradient(circle at 30% 30%, #FCA5E5, #BE185D 70%, #581C87)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 32, boxShadow: '0 0 24px rgba(247,112,199,.6)', flexShrink: 0
        }}>👑</div>
        <div style={{ flex: 1, color: '#fff' }}>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 15 }}>모의고사 보스</div>
          <div style={{ fontSize: 10, color: 'var(--r-ink-dim)', fontFamily: 'var(--font-mono)', textTransform: 'uppercase', letterSpacing: '.06em', marginBottom: 8 }}>LV.50 · TIER S</div>
          <div className="r-bar-track" style={{ height: 12 }}>
            <div className="r-bar-fill hp" style={{ width: '74%' }}/>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4 }}>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: '#FDA29B', fontWeight: 700 }}>BOSS HP</span>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: '#fff', fontWeight: 800 }}>37 / 50</span>
          </div>
        </div>
      </div>
    </div>

    <div className="r-mobile-body" style={{ paddingTop: 0 }}>
      {/* Question */}
      <div style={{
        padding: 16, borderRadius: 14,
        background: 'rgba(255,255,255,.05)',
        border: '1px solid rgba(189,180,254,.15)',
        marginBottom: 12
      }}>
        <div style={{ display: 'flex', gap: 6, marginBottom: 10 }}>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, fontWeight: 800, letterSpacing: '.08em', padding: '3px 8px', background: 'rgba(250,197,21,.15)', color: '#FAC515', borderRadius: 4 }}>Q.14 / 50</span>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, fontWeight: 800, letterSpacing: '.08em', padding: '3px 8px', background: 'rgba(189,180,254,.15)', color: '#BDB4FE', borderRadius: 4 }}>2-1 · JOIN</span>
          <span style={{ marginLeft: 'auto', fontSize: 11, color: '#FAC515' }}>⚔ +20 DMG</span>
        </div>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: 14, fontWeight: 600, lineHeight: 1.5, color: '#fff', marginBottom: 12 }}>
          NULL 값이 포함된 컬럼끼리 INNER JOIN을 수행했을 때 결과로 가장 적절한 것은?
        </div>

        {[
          { l: 'A', t: 'NULL = NULL이 TRUE로 평가되어 모두 매칭된다.' },
          { l: 'B', t: 'NULL을 포함한 행은 조인 결과에서 제외된다.', sel: true },
          { l: 'C', t: '에러가 발생한다.' },
          { l: 'D', t: 'NULL은 빈 문자열로 변환되어 매칭된다.' },
        ].map((x, i) => (
          <div key={i} style={{
            padding: '10px 12px', borderRadius: 10, marginBottom: 6,
            background: x.sel ? 'rgba(250,197,21,.15)' : 'rgba(0,0,0,.25)',
            border: `1.5px solid ${x.sel ? '#FAC515' : 'rgba(189,180,254,.12)'}`,
            display: 'flex', gap: 10, alignItems: 'center', cursor: 'pointer'
          }}>
            <div style={{
              width: 24, height: 24, borderRadius: 6,
              background: x.sel ? '#FAC515' : 'rgba(255,255,255,.06)',
              color: x.sel ? '#1A0F3E' : 'var(--r-ink-dim)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontWeight: 800, fontFamily: 'var(--font-mono)', fontSize: 11, flexShrink: 0
            }}>{x.l}</div>
            <div style={{ fontSize: 12, color: '#fff', fontWeight: 500, lineHeight: 1.4 }}>{x.t}</div>
          </div>
        ))}
      </div>

      {/* Combo meter */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 12,
        padding: '10px 14px', borderRadius: 10,
        background: 'linear-gradient(90deg, rgba(250,197,21,.2), rgba(249,112,102,.2))',
        border: '1px solid rgba(250,197,21,.3)',
        marginBottom: 12
      }}>
        <span style={{ fontSize: 22 }}>🔥</span>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 11, color: '#FAC515', fontWeight: 700, fontFamily: 'var(--font-mono)', textTransform: 'uppercase', letterSpacing: '.06em' }}>COMBO</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 16, fontWeight: 800, color: '#fff' }}>5연속 정답! <span style={{ color: '#FAC515' }}>× 1.5</span></div>
        </div>
      </div>
    </div>

    {/* CTA */}
    <div style={{ padding: '12px 16px 28px', display: 'flex', gap: 8 }}>
      <button style={{ width: 48, height: 48, borderRadius: 12, background: 'rgba(255,255,255,.08)', border: 0, color: '#fff' }}>
        <IBM size={18}/>
      </button>
      <button style={{
        flex: 1, height: 48, borderRadius: 12, border: 0,
        background: 'linear-gradient(135deg, #FAC515, #F97066)',
        color: '#1A0F3E', fontWeight: 900, fontSize: 14,
        fontFamily: 'var(--font-mono)', textTransform: 'uppercase', letterSpacing: '.06em',
        boxShadow: '0 6px 0 #9A3412'
      }}>⚔ 공격 (정답 제출)</button>
    </div>
  </div>
);

Object.assign(window, { RpgDesktop, RpgMobile, RpgBossBattle });
