/* eslint-disable */
/* Variant B — "Pro Trainer" (Fitness/data-rich style) */

const ProDesktop = () => {
  return (
    <div className="p p-canvas">
      <div className="p-topbar">
        <div className="p-brand">
          <div className="p-brand-mark"/>
          SQLD<span style={{ color: 'var(--purple-600)' }}>.</span>training
        </div>
        <nav className="p-nav">
          <a className="on">Today</a>
          <a>Theory</a>
          <a>Practice</a>
          <a>Insights</a>
          <a>Coach</a>
        </nav>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <span className="p-streak-pill"><IFlame size={14}/> 14d streak</span>
          <div style={{
            width: 36, height: 36, borderRadius: 50, background: 'var(--gray-900)', color: '#fff',
            display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 13
          }}>진수</div>
        </div>
      </div>

      <div className="p-main">
        <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 28, gap: 16 }}>
          <div>
            <div style={{ fontSize: 13, color: 'var(--gray-500)', fontWeight: 600, marginBottom: 4 }}>
              월요일 · 5월 17일 · D-23 시험까지
            </div>
            <h1 className="p-h1">오늘도 한 세트 가볼까요, 진수님</h1>
            <p className="p-sub">코치가 추천한 오늘 목표: <b style={{ color: 'var(--gray-900)' }}>SQL 활용 25문항 · 45분</b></p>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button style={{
              height: 40, padding: '0 18px', borderRadius: 10,
              background: 'var(--gray-900)', color: '#fff', border: 0,
              fontWeight: 700, fontSize: 14, display: 'inline-flex', alignItems: 'center', gap: 8, cursor: 'pointer'
            }}>
              <IPlay size={14}/> Start session
            </button>
            <button style={{
              height: 40, padding: '0 18px', borderRadius: 10,
              background: '#fff', border: '1px solid var(--gray-300)', color: 'var(--gray-700)',
              fontWeight: 600, fontSize: 14, cursor: 'pointer'
            }}>Customize</button>
          </div>
        </div>

        {/* Row 1: Rings + Today plan + Coach */}
        <div className="p-grid" style={{ gridTemplateColumns: '1.2fr 1fr 1fr', marginBottom: 20 }}>
          <div className="p-card dark">
            <div className="p-card-title" style={{ color: 'rgba(255,255,255,.6)' }}>
              오늘의 활동 <span className="more" style={{ color: 'rgba(255,255,255,.5)' }}>RESET 23:42</span>
            </div>
            <div className="p-rings-wrap">
              <div style={{ position: 'relative' }}>
                <ActivityRings size={210}/>
                <div style={{
                  position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column',
                  alignItems: 'center', justifyContent: 'center', textAlign: 'center'
                }}>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, opacity: .6, fontWeight: 600 }}>OVERALL</div>
                  <div style={{ fontFamily: 'var(--font-display)', fontSize: 36, fontWeight: 800 }}>72%</div>
                </div>
              </div>
              <div className="p-rings-legend">
                <div className="p-legend-row">
                  <span className="p-legend-dot" style={{ background: '#F670C7' }}/>
                  <span className="p-legend-name">풀이량</span>
                  <span className="p-legend-val" style={{ color: '#fff' }}>32 / 45</span>
                </div>
                <div className="p-legend-row" style={{ borderColor: 'rgba(255,255,255,.1)' }}>
                  <span className="p-legend-dot" style={{ background: '#FAC515' }}/>
                  <span className="p-legend-name">정답률</span>
                  <span className="p-legend-val" style={{ color: '#fff' }}>78%</span>
                </div>
                <div className="p-legend-row" style={{ borderColor: 'rgba(255,255,255,.1)' }}>
                  <span className="p-legend-dot" style={{ background: '#12B76A' }}/>
                  <span className="p-legend-name">학습 시간</span>
                  <span className="p-legend-val" style={{ color: '#fff' }}>54m / 60m</span>
                </div>
              </div>
            </div>
          </div>

          <div className="p-card">
            <div className="p-card-title">오늘의 플랜 <span className="more">3 / 5 완료</span></div>
            {[
              { t: '서브쿼리 복습',     dur: '12m', done: true },
              { t: 'JOIN 약점 보강',   dur: '15m', done: true },
              { t: 'SQL 활용 모의 풀이', dur: '20m', done: true },
              { t: '오답 노트 정리',   dur: '8m',  done: false, now: true },
              { t: '내일 예습',         dur: '5m',  done: false },
            ].map((x, i) => (
              <div key={i} style={{
                display: 'flex', alignItems: 'center', gap: 10, padding: '10px 0',
                borderBottom: i < 4 ? '1px solid var(--gray-100)' : 0,
              }}>
                <div style={{
                  width: 22, height: 22, borderRadius: 6, flexShrink: 0,
                  background: x.done ? 'var(--gray-900)' : x.now ? '#fff' : '#fff',
                  border: x.done ? 0 : `2px solid ${x.now ? 'var(--gray-900)' : 'var(--gray-300)'}`,
                  color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center'
                }}>{x.done && <ICheck size={14}/>}{x.now && <span style={{ width: 8, height: 8, background: 'var(--gray-900)', borderRadius: 50 }}/>}</div>
                <div style={{ flex: 1, fontSize: 13, fontWeight: 600, color: x.done ? 'var(--gray-400)' : 'var(--gray-900)', textDecoration: x.done ? 'line-through' : 'none' }}>{x.t}</div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--gray-400)', fontWeight: 600 }}>{x.dur}</div>
              </div>
            ))}
          </div>

          <div className="p-card" style={{ background: 'linear-gradient(135deg, #F4F3FF 0%, #FFE5F1 100%)', borderColor: '#E9D5FF' }}>
            <div className="p-card-title">코치 한마디</div>
            <div style={{ display: 'flex', gap: 14, alignItems: 'flex-start' }}>
              <OwlCoach size={72}/>
              <div style={{ flex: 1, fontSize: 13, lineHeight: 1.5, color: 'var(--gray-700)' }}>
                <p style={{ margin: '0 0 8px', fontWeight: 700, color: 'var(--gray-900)' }}>
                  "JOIN 정답률이 7%p 올랐어요! 👏"
                </p>
                <p style={{ margin: 0 }}>
                  서브쿼리는 아직 약점이에요. 오늘은 <b>중첩 서브쿼리 5문제</b>로 워밍업하는 걸 추천드려요.
                </p>
              </div>
            </div>
            <button style={{
              width: '100%', marginTop: 14, padding: '10px 14px', borderRadius: 10,
              background: 'var(--gray-900)', color: '#fff', border: 0,
              fontWeight: 700, fontSize: 13, cursor: 'pointer'
            }}>코치 추천 시작 →</button>
          </div>
        </div>

        {/* Row 2: KPI stat strip */}
        <div className="p-stat-grid" style={{ marginBottom: 20 }}>
          {[
            { lbl: 'TOTAL XP',      val: '12,480', delta: '+340 today', spark: [40,50,45,60,68,72,80,90,88,100], color: '#7F56D9' },
            { lbl: '풀이한 문제',   val: '342',    delta: '+28 vs 지난주', spark: [30,35,40,38,55,60,68,72,80,90], color: '#F670C7' },
            { lbl: '평균 정답률',   val: '78%',    delta: '+6%p',         spark: [60,64,62,68,70,72,74,76,77,78], color: '#FAC515' },
            { lbl: '평균 풀이 시간', val: '42s',   delta: '-8s',           spark: [60,58,55,52,48,46,45,44,43,42], color: '#12B76A', down: true },
          ].map((x, i) => (
            <div key={i} className="p-card" style={{ padding: '16px 18px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--gray-500)', fontWeight: 700, letterSpacing: '.08em' }}>{x.lbl}</div>
                  <div className="p-h1" style={{ fontSize: 28, marginTop: 4 }}>{x.val}</div>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, fontWeight: 600, color: x.down ? 'var(--gray-500)' : 'var(--green-700)', marginTop: 2 }}>
                    {x.delta}
                  </div>
                </div>
              </div>
              <div style={{ marginTop: 8 }}>
                <Sparkline data={x.spark} color={x.color} h={48}/>
              </div>
            </div>
          ))}
        </div>

        {/* Row 3: Heatmap + Radar */}
        <div className="p-grid" style={{ gridTemplateColumns: '1.4fr 1fr', marginBottom: 20 }}>
          <div className="p-card">
            <div className="p-card-title">최근 84일 활동 <span className="more">142h 13m 누적</span></div>
            <div className="p-heatmap" style={{ gridTemplateColumns: 'repeat(14, 1fr)' }}>
              {heatmapData.map((v, i) => (
                <div key={i} className={`p-heat l${v}`}/>
              ))}
            </div>
            <div className="p-heat-axis">
              <span>5월 17일</span>
              <span style={{ flex: 1, textAlign: 'center' }}>· · · 매일 학습 ·  ·  ·</span>
              <span>오늘</span>
              <div className="scale">
                <span style={{ background: '#F2F4F7' }}/>
                <span style={{ background: '#E9D5FF' }}/>
                <span style={{ background: '#BDB4FE' }}/>
                <span style={{ background: '#9B8AFB' }}/>
                <span style={{ background: '#7F56D9' }}/>
                <span style={{ background: '#53389E' }}/>
              </div>
            </div>
            <div style={{ display: 'flex', gap: 24, marginTop: 20, paddingTop: 16, borderTop: '1px solid var(--gray-100)' }}>
              {[
                { l: '최장 연속',  v: '21일'},
                { l: '평균/일',     v: '24분' },
                { l: '주말 비율',  v: '38%' },
                { l: '가장 활발', v: '21~23시' },
              ].map((x, i) => (
                <div key={i}>
                  <div style={{ fontSize: 11, color: 'var(--gray-500)', fontWeight: 600 }}>{x.l}</div>
                  <div style={{ fontFamily: 'var(--font-display)', fontSize: 18, fontWeight: 700, marginTop: 2 }}>{x.v}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="p-card">
            <div className="p-card-title">영역별 정답률 <span className="more">최근 30일</span></div>
            <div style={{ display: 'flex', justifyContent: 'center' }}>
              <Radar size={260} values={[88, 82, 64, 71, 78]} />
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, marginTop: 8 }}>
              <span style={{ color: 'var(--gray-500)' }}>가장 강한 영역</span>
              <span style={{ fontWeight: 700 }}>데이터 모델링 88%</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, marginTop: 4 }}>
              <span style={{ color: 'var(--gray-500)' }}>가장 약한 영역</span>
              <span style={{ fontWeight: 700, color: 'var(--red-600)' }}>SQL 활용 64%</span>
            </div>
          </div>
        </div>

        {/* Row 4: Chapter list */}
        <div className="p-card" style={{ padding: 0 }}>
          <div style={{ padding: '18px 22px 12px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div className="p-card-title" style={{ margin: 0 }}>챕터별 성과</div>
            <div style={{ display: 'flex', gap: 6 }}>
              <button style={{ padding: '4px 10px', borderRadius: 6, background: 'var(--gray-900)', color: '#fff', border: 0, fontSize: 11, fontWeight: 700 }}>전체</button>
              <button style={{ padding: '4px 10px', borderRadius: 6, background: '#fff', border: '1px solid var(--gray-200)', fontSize: 11, fontWeight: 600, color: 'var(--gray-600)' }}>1과목</button>
              <button style={{ padding: '4px 10px', borderRadius: 6, background: '#fff', border: '1px solid var(--gray-200)', fontSize: 11, fontWeight: 600, color: 'var(--gray-600)' }}>2과목</button>
            </div>
          </div>
          <div>
            {[
              { ch: '1과목 1장', n: '데이터 모델링의 이해', rate: 88, prog: 100, time: '2h 14m', xp: 1240 },
              { ch: '1과목 2장', n: '데이터 모델과 성능',     rate: 82, prog: 100, time: '1h 52m', xp: 980 },
              { ch: '2과목 1장', n: 'SQL 기본',                rate: 78, prog: 64,  time: '3h 08m', xp: 1820, current: true },
              { ch: '2과목 2장', n: 'SQL 활용',                rate: 64, prog: 22,  time: '48m',     xp: 420 },
              { ch: '2과목 3장', n: 'SQL 최적화 기본 원리',    rate: null, prog: 0, time: '—',       xp: 0 },
            ].map((x, i) => (
              <div key={i} style={{
                display: 'grid', gridTemplateColumns: '90px 1.5fr 1fr 1fr 1fr auto', alignItems: 'center', gap: 16,
                padding: '14px 22px', borderTop: '1px solid var(--gray-100)',
                background: x.current ? '#FAFAFF' : '#fff'
              }}>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, fontWeight: 700, color: 'var(--gray-500)' }}>{x.ch}</div>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 14 }}>{x.n}</div>
                  <div style={{ fontSize: 11, color: 'var(--gray-500)', fontFamily: 'var(--font-mono)', marginTop: 2 }}>
                    {x.time} · {x.xp.toLocaleString()} XP
                  </div>
                </div>
                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, color: 'var(--gray-500)', fontWeight: 600 }}>
                    <span>진도</span><span style={{ fontFamily: 'var(--font-mono)' }}>{x.prog}%</span>
                  </div>
                  <div style={{ height: 6, background: 'var(--gray-100)', borderRadius: 999, marginTop: 4, overflow: 'hidden' }}>
                    <div style={{ width: `${x.prog}%`, height: '100%', background: 'var(--gray-900)', borderRadius: 999 }}/>
                  </div>
                </div>
                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, color: 'var(--gray-500)', fontWeight: 600 }}>
                    <span>정답률</span><span style={{ fontFamily: 'var(--font-mono)', color: x.rate === null ? 'var(--gray-400)' : x.rate < 70 ? 'var(--red-600)' : 'var(--green-700)' }}>{x.rate === null ? '—' : `${x.rate}%`}</span>
                  </div>
                  <div style={{ height: 6, background: 'var(--gray-100)', borderRadius: 999, marginTop: 4, overflow: 'hidden' }}>
                    <div style={{ width: `${x.rate || 0}%`, height: '100%', background: x.rate === null ? '#fff' : x.rate < 70 ? 'var(--red-500)' : 'var(--green-500)', borderRadius: 999 }}/>
                  </div>
                </div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--gray-500)', fontWeight: 600 }}>
                  {x.prog === 100 ? <span style={{ color: 'var(--green-700)' }}>● 완료</span> : x.current ? <span style={{ color: 'var(--purple-600)' }}>● 진행 중</span> : x.prog === 0 ? <span style={{ color: 'var(--gray-400)' }}>○ 시작 전</span> : <span style={{ color: 'var(--gray-700)' }}>● 일시중단</span>}
                </div>
                <button style={{
                  padding: '6px 12px', borderRadius: 6, fontSize: 12, fontWeight: 700, cursor: 'pointer',
                  background: x.current ? 'var(--gray-900)' : '#fff', color: x.current ? '#fff' : 'var(--gray-700)',
                  border: x.current ? 0 : '1px solid var(--gray-300)'
                }}>{x.current ? '이어서' : x.prog === 100 ? '복습' : '시작'}</button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

// ── Mobile dashboard ────────────────────────────────────────
const ProMobile = () => (
  <div className="p-mobile">
    <div className="p-mobile-top">
      <div className="p-mobile-greeting">
        오늘도 가볼까요?
        <div className="sub">5월 17일 · 월요일</div>
      </div>
      <div style={{ width: 38, height: 38, borderRadius: 50, background: 'var(--gray-900)', color: '#fff',
        display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 13 }}>진</div>
    </div>

    <div className="p-mobile-body">
      <div style={{
        background: 'var(--gray-900)', color: '#fff', borderRadius: 20, padding: 18, marginBottom: 14
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 18 }}>
          <ActivityRings size={130}/>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, opacity: .6, fontWeight: 700, letterSpacing: '.08em' }}>오늘</div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 28, fontWeight: 800, lineHeight: 1.1, margin: '2px 0 8px' }}>72%</div>
            {[
              { c: '#F670C7', n: '풀이', v: '32/45' },
              { c: '#FAC515', n: '정답률', v: '78%' },
              { c: '#12B76A', n: '시간', v: '54m' },
            ].map((x,i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
                <span style={{ width: 8, height: 8, borderRadius: 50, background: x.c }}/>
                <span style={{ fontSize: 11, opacity: .8, fontWeight: 500 }}>{x.n}</span>
                <span style={{ marginLeft: 'auto', fontFamily: 'var(--font-mono)', fontSize: 12, fontWeight: 700 }}>{x.v}</span>
              </div>
            ))}
          </div>
        </div>
        <button style={{
          marginTop: 14, width: '100%', padding: '12px', borderRadius: 12,
          background: '#fff', color: 'var(--gray-900)', border: 0,
          fontWeight: 700, fontSize: 14, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8
        }}>
          <IPlay size={14}/> 오늘 세션 시작
        </button>
      </div>

      {/* Coach card */}
      <div style={{
        background: 'linear-gradient(135deg, #F4F3FF, #FFE5F1)',
        borderRadius: 16, padding: 14, marginBottom: 14,
        display: 'flex', gap: 12, alignItems: 'flex-start',
        border: '1px solid #E9D5FF'
      }}>
        <OwlCoach size={56}/>
        <div style={{ flex: 1, fontSize: 12, lineHeight: 1.5 }}>
          <div style={{ fontWeight: 700, marginBottom: 2 }}>JOIN 정답률 7%p↑</div>
          <div style={{ color: 'var(--gray-600)' }}>오늘은 중첩 서브쿼리 5문제로 약점을 보강해볼까요?</div>
        </div>
      </div>

      {/* KPI 2x2 */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 14 }}>
        {[
          { lbl: 'TOTAL XP',   val: '12,480', d: '+340 today', c: '#7F56D9' },
          { lbl: '문제 풀이',  val: '342',    d: '+28 wk',     c: '#F670C7' },
          { lbl: '정답률',     val: '78%',    d: '+6%p',        c: '#FAC515' },
          { lbl: '평균 풀이',  val: '42s',    d: '-8s',          c: '#12B76A' },
        ].map((x, i) => (
          <div key={i} style={{ background: '#fff', border: '1px solid var(--gray-200)', borderRadius: 14, padding: 12 }}>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, fontWeight: 700, letterSpacing: '.08em', color: 'var(--gray-500)' }}>{x.lbl}</div>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 22, lineHeight: 1.1, marginTop: 4 }}>{x.val}</div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, fontWeight: 600, color: 'var(--green-700)', marginTop: 2 }}>{x.d}</div>
          </div>
        ))}
      </div>

      {/* Heatmap */}
      <div style={{ background: '#fff', borderRadius: 16, border: '1px solid var(--gray-200)', padding: 14, marginBottom: 14 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 10 }}>
          <div style={{ fontWeight: 700, fontSize: 13 }}>학습 캘린더</div>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--gray-500)', fontWeight: 600 }}>84일</div>
        </div>
        <div className="p-heatmap" style={{ gridTemplateColumns: 'repeat(14, 1fr)', gap: 3 }}>
          {heatmapData.map((v, i) => <div key={i} className={`p-heat l${v}`} style={{ borderRadius: 2 }}/>)}
        </div>
      </div>

      {/* Quick chapter list */}
      <div style={{ background: '#fff', borderRadius: 16, border: '1px solid var(--gray-200)', overflow: 'hidden' }}>
        <div style={{ padding: '14px 14px 6px', fontWeight: 700, fontSize: 13 }}>챕터별 성과</div>
        {[
          { n: 'SQL 기본',  rate: 78, prog: 64, current: true },
          { n: 'SQL 활용',  rate: 64, prog: 22 },
          { n: '데이터 모델링', rate: 88, prog: 100 },
        ].map((x, i) => (
          <div key={i} style={{
            padding: '12px 14px', borderTop: '1px solid var(--gray-100)',
            display: 'flex', alignItems: 'center', gap: 12,
            background: x.current ? '#FAFAFF' : '#fff'
          }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 700, fontSize: 13 }}>{x.n}</div>
              <div style={{ height: 6, background: 'var(--gray-100)', borderRadius: 999, marginTop: 6, overflow: 'hidden' }}>
                <div style={{ width: `${x.prog}%`, height: '100%', background: 'var(--gray-900)', borderRadius: 999 }}/>
              </div>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--gray-500)', fontWeight: 600 }}>정답률</div>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 18, color: x.rate < 70 ? 'var(--red-600)' : 'var(--gray-900)' }}>{x.rate}%</div>
            </div>
          </div>
        ))}
      </div>
    </div>

    {/* Tab bar */}
    <div style={{
      position: 'absolute', bottom: 0, left: 0, right: 0,
      background: '#fff', borderTop: '1px solid var(--gray-200)',
      display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)',
      padding: '10px 8px 24px',
    }}>
      {[
        { i: <IHome size={20}/>, l: 'Today', on: true },
        { i: <IBook size={20}/>, l: 'Theory' },
        { i: <IPencil size={20}/>, l: 'Practice' },
        { i: <IChart size={20}/>, l: 'Insights' },
        { i: <OwlCoach size={22}/>, l: 'Coach' },
      ].map((x, i) => (
        <a key={i} style={{
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
          fontSize: 10, fontWeight: 600, color: x.on ? 'var(--gray-900)' : 'var(--gray-500)'
        }}>{x.i}<span>{x.l}</span></a>
      ))}
    </div>
  </div>
);

// ── Mobile session/quiz screen ───────────────────────────────
const ProMobileQuiz = () => (
  <div className="p-mobile" style={{ background: 'var(--gray-900)', color: '#fff' }}>
    <div style={{ padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 8 }}>
      <button style={{ width: 32, height: 32, borderRadius: 8, background: 'rgba(255,255,255,.1)', color: '#fff', border: 0 }}>×</button>
      <div style={{ flex: 1, marginLeft: 4 }}>
        <div style={{ height: 6, background: 'rgba(255,255,255,.15)', borderRadius: 999, overflow: 'hidden' }}>
          <div style={{ width: '40%', height: '100%', background: '#F670C7', borderRadius: 999 }}/>
        </div>
      </div>
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, fontWeight: 700 }}>12/30</span>
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, fontWeight: 700, color: '#FAC515', display: 'inline-flex', alignItems: 'center', gap: 4 }}>
        <IClock size={12}/> 23:08
      </span>
    </div>

    <div className="p-mobile-body" style={{ paddingTop: 12 }}>
      <div style={{ display: 'flex', gap: 6, marginBottom: 14 }}>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, fontWeight: 700, letterSpacing: '.06em', padding: '3px 8px', background: 'rgba(255,255,255,.1)', borderRadius: 4 }}>2과목 · 1장</span>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, fontWeight: 700, letterSpacing: '.06em', padding: '3px 8px', background: 'rgba(246,112,199,.2)', color: '#FCA5E5', borderRadius: 4 }}>JOIN</span>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, fontWeight: 700, letterSpacing: '.06em', padding: '3px 8px', background: 'rgba(250,197,21,.2)', color: '#FDE272', borderRadius: 4, marginLeft: 'auto' }}>중급</span>
      </div>

      <div style={{ fontFamily: 'var(--font-display)', fontSize: 17, fontWeight: 600, lineHeight: 1.5, marginBottom: 18 }}>
        다음 SQL 결과로 옳은 것은? EMP 테이블과 DEPT 테이블을 LEFT OUTER JOIN 했을 때 DEPT가 NULL인 행도 함께 출력된다. 부서가 없는 사원을 찾기 위해 사용하는 방식은?
      </div>
      <div style={{ background: 'rgba(255,255,255,.05)', borderRadius: 12, padding: 12, fontFamily: 'var(--font-mono)', fontSize: 12, lineHeight: 1.7, marginBottom: 18, color: '#BDB4FE' }}>
        SELECT e.ename, d.dname<br/>
        FROM EMP e LEFT JOIN DEPT d<br/>
        ON e.deptno = d.deptno<br/>
        WHERE d.deptno IS NULL;
      </div>

      {[
        { l: 'A', t: 'EMP에 있는 모든 사원과 부서 정보 출력',  sel: false },
        { l: 'B', t: '부서가 없는 사원만 출력',                  sel: true },
        { l: 'C', t: '사원이 없는 부서만 출력',                  sel: false },
        { l: 'D', t: '모든 조합을 출력 (CROSS JOIN과 동일)',     sel: false },
      ].map((x, i) => (
        <div key={i} style={{
          padding: '14px 16px', borderRadius: 12, marginBottom: 8,
          border: `2px solid ${x.sel ? '#F670C7' : 'rgba(255,255,255,.12)'}`,
          background: x.sel ? 'rgba(246,112,199,.12)' : 'rgba(255,255,255,.04)',
          display: 'flex', gap: 12, alignItems: 'center', cursor: 'pointer'
        }}>
          <div style={{
            width: 28, height: 28, borderRadius: 8,
            background: x.sel ? '#F670C7' : 'rgba(255,255,255,.08)', color: x.sel ? '#101828' : '#BDB4FE',
            display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800,
            fontFamily: 'var(--font-mono)', fontSize: 13
          }}>{x.l}</div>
          <div style={{ fontSize: 13, fontWeight: 500 }}>{x.t}</div>
        </div>
      ))}
    </div>

    <div style={{ padding: '12px 16px 24px', display: 'flex', gap: 10, borderTop: '1px solid rgba(255,255,255,.1)' }}>
      <button style={{
        width: 48, height: 48, borderRadius: 12, background: 'rgba(255,255,255,.08)',
        border: 0, color: '#fff'
      }}><IBM size={18}/></button>
      <button style={{
        flex: 1, height: 48, borderRadius: 12, border: 0,
        background: '#F670C7', color: '#101828',
        fontWeight: 800, fontSize: 15
      }}>정답 확인 →</button>
    </div>
  </div>
);

Object.assign(window, { ProDesktop, ProMobile, ProMobileQuiz });
