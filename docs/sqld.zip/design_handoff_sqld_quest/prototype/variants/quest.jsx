/* eslint-disable */
/* Variant A — "Quest Mode" (Duolingo-like learning path) */

const QuestDesktop = () => {
  const chapters = [
    { id: 'p1c1', title: '데이터 모델링의 이해', sub: '1과목 · 18문항', state: 'done',    icon: '🗂️' },
    { id: 'p1c2', title: '데이터 모델과 성능',     sub: '1과목 · 22문항', state: 'done',    icon: '⚙️' },
    { id: 'p2c1', title: 'SQL 기본',                sub: '2과목 · 28문항', state: 'current', icon: '📝', progress: 64 },
    { id: 'p2c2', title: 'SQL 활용',                sub: '2과목 · 24문항', state: 'locked',  icon: '🔧' },
    { id: 'p2c3', title: 'SQL 최적화 기본 원리',    sub: '2과목 · 14문항', state: 'locked',  icon: '⚡' },
    { id: 'exam', title: '모의고사 · 보스 도전',     sub: '50문항 · 90분',  state: 'boss',    icon: '👑' },
  ];

  return (
    <div className="q q-canvas">
      <div className="q-topbar">
        <div className="q-brand">
          <div className="q-brand-mark">Q</div>
          <span>SQLD 퀘스트</span>
        </div>
        <nav className="q-nav">
          <a className="on">홈</a>
          <a>이론</a>
          <a>문제풀기</a>
          <a>리그</a>
          <a>도감</a>
        </nav>
        <div className="q-stats">
          <span className="q-stat streak"><IFlame size={16}/> 14일</span>
          <span className="q-stat gem"><IGem size={16}/> 1,420</span>
          <span className="q-stat heart"><IHeart size={16}/> 4 / 5</span>
          <span className="q-avatar">진</span>
        </div>
      </div>

      <div className="q-grid">
        {/* LEFT: Hero + Path */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
          <div className="q-hero">
            <div style={{ flex: '0 0 180px' }}>
              <Querymon size={180} wave />
            </div>
            <div className="q-hero-text">
              <div style={{
                display: 'inline-flex', alignItems: 'center', gap: 6,
                background: 'rgba(255,255,255,.18)', padding: '4px 10px', borderRadius: 999,
                fontSize: 12, fontWeight: 700, marginBottom: 10, letterSpacing: '.04em'
              }}>
                <IBolt size={12}/> 오늘의 퀘스트
              </div>
              <h1>SQL 기본을 끝내고<br/>"쿼리몬"을 진화시켜요!</h1>
              <p>현재 SQL 기본 챕터의 64% 진행 중 · 정답 7개만 더 맞히면 보너스 💎</p>
              <div style={{ display: 'flex', gap: 10, marginTop: 16 }}>
                <button className="q-hero-cta">
                  <IPlay size={14}/> 이어서 풀기
                </button>
                <button className="q-hero-cta" style={{ background: 'rgba(255,255,255,.15)', color: '#fff', boxShadow: 'none' }}>
                  <IBook size={14}/> 이론 복습
                </button>
              </div>
            </div>
          </div>

          <div className="q-card">
            <div className="q-card-title">
              학습 여정 <span className="small">전체 5장 + 보스 1</span>
            </div>
            <div className="q-path">
              {chapters.map((c, i) => (
                <React.Fragment key={c.id}>
                  <div className={`q-path-node ${c.state}`} style={{ alignSelf: i % 2 ? 'flex-end' : 'flex-start', marginLeft: i%2 ? 'auto' : 80, marginRight: i%2 ? 80 : 'auto' }}>
                    {i % 2 === 0 ? (
                      <>
                        <div className="bubble">
                          {c.state === 'done' ? <ICheck size={28}/> :
                           c.state === 'locked' ? <ILock size={22}/> :
                           c.state === 'boss' ? c.icon :
                           c.icon}
                        </div>
                        <div className="q-path-label">
                          <div className="t">{c.title}</div>
                          <div className="s">{c.sub}{c.progress ? ` · ${c.progress}%` : ''}</div>
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="q-path-label" style={{ textAlign: 'right' }}>
                          <div className="t">{c.title}</div>
                          <div className="s">{c.sub}{c.progress ? ` · ${c.progress}%` : ''}</div>
                        </div>
                        <div className="bubble">
                          {c.state === 'done' ? <ICheck size={28}/> :
                           c.state === 'locked' ? <ILock size={22}/> :
                           c.state === 'boss' ? c.icon :
                           c.icon}
                        </div>
                      </>
                    )}
                  </div>
                  {i < chapters.length - 1 && (
                    <div className={`q-path-link ${c.state === 'done' ? 'done' : ''}`}/>
                  )}
                </React.Fragment>
              ))}
            </div>
          </div>
        </div>

        {/* RIGHT: side panels */}
        <aside className="q-side">
          <div className="q-mascot-card">
            <div className="speech">"오늘도 시작해볼까요?<br/>3문제만 풀어도 콤보 유지!"</div>
            <Querymon size={140}/>
            <div style={{ fontSize: 12, color: 'var(--gray-600)', fontWeight: 600, marginTop: 4 }}>
              쿼리몬 · Lv. 7 · 다음 진화까지 320XP
            </div>
          </div>

          <div className="q-card">
            <div className="q-card-title">이번 주 XP <span className="small">+1,240 XP</span></div>
            <div className="q-bars">
              {[80, 60, 100, 45, 90, 55, 70].map((h, i) => (
                <div key={i} style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                  <div className={`q-bar ${i === 6 ? 'today' : ''}`} style={{ height: `${h}%` }}/>
                  <div className={`q-bar-day ${i === 6 ? 'today' : ''}`}>{['월','화','수','목','금','토','일'][i]}</div>
                </div>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 12, marginTop: 14, paddingTop: 14, borderTop: '1px dashed var(--gray-200)' }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 11, color: 'var(--gray-500)', fontWeight: 600 }}>주간 목표</div>
                <div style={{ fontSize: 18, fontWeight: 800, marginTop: 2 }}>83 / 100</div>
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 11, color: 'var(--gray-500)', fontWeight: 600 }}>리그 순위</div>
                <div style={{ fontSize: 18, fontWeight: 800, marginTop: 2, color: '#A15C07' }}>🥉 12위</div>
              </div>
            </div>
          </div>

          <div className="q-card">
            <div className="q-card-title">취약 챕터 TOP 3</div>
            {[
              { n: 'SQL 기본 — JOIN',           rate: 42, color: '#FF6B6B' },
              { n: '서브쿼리 / 집합 연산자',     rate: 51, color: '#FFB627' },
              { n: '인덱스와 옵티마이저',        rate: 58, color: '#FFB627' },
            ].map((x, i) => (
              <div key={i} style={{ marginBottom: 12 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4, fontSize: 13, fontWeight: 600 }}>
                  <span>{x.n}</span>
                  <span style={{ color: x.color, fontFamily: 'var(--font-mono)' }}>{x.rate}%</span>
                </div>
                <div style={{ height: 8, background: 'var(--gray-100)', borderRadius: 999, overflow: 'hidden' }}>
                  <div style={{ height: '100%', width: `${x.rate}%`, background: x.color, borderRadius: 999 }}/>
                </div>
              </div>
            ))}
            <button style={{
              width: '100%', padding: 10, borderRadius: 12, marginTop: 4,
              background: '#F4F3FF', color: '#53389E', border: 0,
              fontWeight: 700, fontSize: 13, cursor: 'pointer'
            }}>약점 집중 훈련 시작</button>
          </div>
        </aside>
      </div>
    </div>
  );
};

// ── Mobile dashboard ───────────────────────────────────────
const QuestMobile = () => {
  const chapters = [
    { state: 'done', icon: '🗂️', t: '데이터 모델링의 이해' },
    { state: 'done', icon: '⚙️', t: '데이터 모델과 성능' },
    { state: 'current', icon: '📝', t: 'SQL 기본', progress: 64 },
    { state: 'locked', icon: '🔧', t: 'SQL 활용' },
    { state: 'locked', icon: '⚡', t: 'SQL 최적화' },
    { state: 'boss', icon: '👑', t: '모의고사 보스' },
  ];
  return (
    <div className="q-mobile">
      <div className="q-mobile-topbar">
        <div style={{
          width: 32, height: 32, borderRadius: 10,
          background: 'linear-gradient(135deg, #7F56D9, #BDB4FE)',
          color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontWeight: 800, fontSize: 14
        }}>Q</div>
        <div className="q-mobile-stats">
          <span className="q-mobile-stat streak"><IFlame size={14}/> 14</span>
          <span className="q-mobile-stat gem"><IGem size={14}/> 1.4k</span>
          <span className="q-mobile-stat heart"><IHeart size={14}/> 4</span>
        </div>
      </div>
      <div className="q-mobile-body">
        {/* Daily quest hero */}
        <div style={{
          background: 'linear-gradient(135deg, #7F56D9, #53389E)',
          borderRadius: 20, padding: 16, color: '#fff',
          display: 'flex', gap: 12, alignItems: 'center', position: 'relative', overflow: 'hidden',
          marginBottom: 16
        }}>
          <div style={{ width: 80, height: 80, flexShrink: 0 }}>
            <Querymon size={80} wave/>
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 11, fontWeight: 700, opacity: .8, letterSpacing: '.04em' }}>오늘의 퀘스트</div>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 17, lineHeight: 1.2, margin: '4px 0' }}>
              SQL JOIN 5문제 풀기
            </div>
            <div style={{ height: 6, background: 'rgba(255,255,255,.2)', borderRadius: 999, marginTop: 6 }}>
              <div style={{ width: '60%', height: '100%', background: '#FAC515', borderRadius: 999 }}/>
            </div>
            <div style={{ fontSize: 11, marginTop: 4, opacity: .85, fontWeight: 600 }}>3 / 5 완료 · +50 💎</div>
          </div>
        </div>

        {/* Stats strip */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8, marginBottom: 16 }}>
          {[
            { l: '풀이율',  v: '57%', c: '#7F56D9' },
            { l: '정답률', v: '78%', c: '#12B76A' },
            { l: '오늘 XP',v: '+180', c: '#FFB627' },
          ].map((x, i) => (
            <div key={i} style={{
              background: '#fff', border: '1px solid var(--gray-100)', borderRadius: 14, padding: 12, textAlign: 'center'
            }}>
              <div style={{ fontSize: 10, color: 'var(--gray-500)', fontWeight: 600 }}>{x.l}</div>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 20, color: x.c, marginTop: 2 }}>{x.v}</div>
            </div>
          ))}
        </div>

        {/* Path */}
        <div style={{
          background: '#fff', borderRadius: 20, border: '1px solid var(--gray-100)', padding: '16px 12px'
        }}>
          <div style={{ fontWeight: 800, fontSize: 14, marginBottom: 12, paddingLeft: 8 }}>학습 여정</div>
          <div className="q-path">
            {chapters.map((c, i) => (
              <React.Fragment key={i}>
                <div className={`q-path-node ${c.state}`} style={{
                  flexDirection: 'column', gap: 6, padding: '4px 0',
                  alignSelf: i % 3 === 1 ? 'flex-end' : i % 3 === 2 ? 'flex-start' : 'center',
                  marginRight: i % 3 === 1 ? 24 : 0, marginLeft: i % 3 === 2 ? 24 : 0,
                }}>
                  <div className="bubble" style={{ width: c.state === 'boss' ? 80 : 64, height: c.state === 'boss' ? 80 : 64, fontSize: c.state === 'boss' ? 26 : 22 }}>
                    {c.state === 'done' ? <ICheck size={24}/> :
                     c.state === 'locked' ? <ILock size={18}/> :
                     c.icon}
                  </div>
                  <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--gray-700)', textAlign: 'center', maxWidth: 120 }}>
                    {c.t}
                    {c.progress !== undefined && (
                      <div style={{ fontSize: 10, color: 'var(--gray-500)', fontWeight: 500 }}>{c.progress}%</div>
                    )}
                  </div>
                </div>
                {i < chapters.length - 1 && <div className="q-path-link" style={{ height: 16, marginLeft: 0 }}/>}
              </React.Fragment>
            ))}
          </div>
        </div>
      </div>

      <div className="q-mobile-nav">
        <a className="on"><IHome size={22} /> 홈</a>
        <a><IBook size={22}/> 이론</a>
        <a><IPencil size={22}/> 풀기</a>
        <a><ITrophy size={22}/> 리그</a>
      </div>
    </div>
  );
};

// ── Mobile chapter "lesson" detail ───────────────────────────
const QuestMobileLesson = () => (
  <div className="q-mobile">
    <div style={{
      padding: '14px 16px 12px',
      background: 'linear-gradient(180deg, #7F56D9, #6941C6)',
      color: '#fff'
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
        <button style={{ background: 'rgba(255,255,255,.2)', border: 0, color: '#fff', width: 32, height: 32, borderRadius: 10 }}>‹</button>
        <div style={{ fontSize: 12, fontWeight: 600, opacity: .85 }}>2과목 · 1장</div>
        <div style={{ marginLeft: 'auto' }}>
          <span className="q-mobile-stat heart" style={{ color: '#fff', background: 'rgba(255,255,255,.18)' }}><IHeart size={14}/> 4</span>
        </div>
      </div>
      <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 22, marginBottom: 4 }}>SQL 기본</div>
      <div style={{ fontSize: 13, opacity: .85, marginBottom: 12 }}>SELECT · FROM · WHERE 기초부터 JOIN까지</div>
      {/* progress */}
      <div style={{ height: 8, background: 'rgba(0,0,0,.2)', borderRadius: 999, overflow: 'hidden' }}>
        <div style={{ width: '64%', height: '100%', background: '#FAC515', borderRadius: 999 }}/>
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 6, fontSize: 12, fontWeight: 600 }}>
        <span>18 / 28 완료</span>
        <span>64%</span>
      </div>
    </div>

    <div className="q-mobile-body" style={{ background: '#FBF9FF' }}>
      {[
        { t: '관계형 모델 기본', done: true,  type: 'theory'   },
        { t: 'SELECT · WHERE',  done: true,  type: 'practice' },
        { t: 'GROUP BY · 집계',  done: true,  type: 'practice' },
        { t: 'JOIN 기초',         done: false, type: 'practice', current: true },
        { t: 'OUTER JOIN',       done: false, type: 'practice' },
        { t: 'NULL 처리',         done: false, type: 'theory'   },
        { t: '미니 시험',         done: false, type: 'mini',    locked: true },
      ].map((step, i) => (
        <div key={i} style={{
          display: 'flex', alignItems: 'center', gap: 12,
          padding: 14, marginBottom: 8,
          background: step.current ? '#fff' : step.done ? '#F4F3FF' : '#fff',
          borderRadius: 16,
          border: step.current ? '2px solid #7F56D9' : '1px solid var(--gray-100)',
          opacity: step.locked ? .5 : 1,
        }}>
          <div style={{
            width: 36, height: 36, borderRadius: 12, flexShrink: 0,
            background: step.done ? '#12B76A' : step.current ? '#7F56D9' : 'var(--gray-100)',
            color: step.done || step.current ? '#fff' : 'var(--gray-400)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            {step.locked ? <ILock size={16}/> : step.done ? <ICheck size={18}/> :
              step.type === 'theory' ? <IBook size={16}/> :
              step.type === 'mini' ? <ITrophy size={16}/> :
              <IPencil size={16}/>}
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 700, fontSize: 14 }}>{step.t}</div>
            <div style={{ fontSize: 11, color: 'var(--gray-500)', fontWeight: 500, marginTop: 2 }}>
              {step.type === 'theory' ? '이론 · 약 3분' : step.type === 'mini' ? '미니 시험 · 10문제' : '문제 풀기 · 5문제'}
            </div>
          </div>
          {step.current && (
            <button style={{
              padding: '8px 14px', borderRadius: 999, background: '#7F56D9', color: '#fff',
              border: 0, fontWeight: 700, fontSize: 12, boxShadow: '0 3px 0 #53389E'
            }}>시작</button>
          )}
        </div>
      ))}
    </div>
  </div>
);

Object.assign(window, { QuestDesktop, QuestMobile, QuestMobileLesson });
