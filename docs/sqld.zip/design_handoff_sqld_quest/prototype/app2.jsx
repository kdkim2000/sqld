/* eslint-disable */
/* App entry — Quest direction expanded: dashboard, theory, result, wrong, bookmarks
   Includes a floating dark/light theme toggle. */

const ThemeToggle = () => {
  const [dark, setDark] = React.useState(() => {
    try { return localStorage.getItem('q-theme') === 'dark'; } catch { return false; }
  });
  React.useEffect(() => {
    document.body.dataset.theme = dark ? 'dark' : 'light';
    try { localStorage.setItem('q-theme', dark ? 'dark' : 'light'); } catch {}
  }, [dark]);
  return (
    <button className="theme-toggle" onClick={() => setDark(d => !d)} aria-label="Toggle theme">
      <span style={{ fontSize: 14 }}>{dark ? '🌙' : '☀️'}</span>
      <span>{dark ? '다크' : '라이트'}</span>
      <span className="knob"/>
    </button>
  );
};

const App = () => (
  <>
    <ThemeToggle/>
    <DesignCanvas
      title="SQLD 합격길잡이 — Quest 방향 전체 페이지"
      subtitle="대시보드 · 이론 · 결과 · 오답 · 북마크 / 라이트·다크 모드 / 데스크탑·모바일"
    >
      <DCSection
        id="dashboard"
        title="① 대시보드"
        subtitle="홈 화면 · 오늘의 퀘스트 + 학습 경로 + 약점 챕터 + 주간 XP"
      >
        <DCArtboard id="dash-d" label="데스크탑" width={1360} height={900}>
          <QuestDesktop />
        </DCArtboard>
        <DCArtboard id="dash-m" label="모바일 · 홈" width={420} height={870}>
          <div className="frame-wrap"><IOSDevice width={390} height={844}><QuestMobile/></IOSDevice></div>
        </DCArtboard>
        <DCArtboard id="dash-m2" label="모바일 · 챕터 진입" width={420} height={870}>
          <div className="frame-wrap"><IOSDevice width={390} height={844}><QuestMobileLesson/></IOSDevice></div>
        </DCArtboard>
      </DCSection>

      <DCSection
        id="theory"
        title="② 이론 학습"
        subtitle="개념 본문 + 마스코트 팁 + 관련 문제 + 챕터 진행률 + 코드 블록"
      >
        <DCArtboard id="theory-d" label="데스크탑 · 본문" width={1360} height={1180}>
          <QuestTheoryDesktop />
        </DCArtboard>
        <DCArtboard id="theory-m" label="모바일 · 본문" width={420} height={870}>
          <div className="frame-wrap"><IOSDevice width={390} height={844}><QuestTheoryMobile/></IOSDevice></div>
        </DCArtboard>
      </DCSection>

      <DCSection
        id="result"
        title="③ 결과 화면"
        subtitle="미션 완료 후 보상 · 별·XP·보석 + 도전과제 + 마스코트 진화 + 문제별 결과"
      >
        <DCArtboard id="result-d" label="데스크탑 · 결과" width={1360} height={1100}>
          <QuestResultDesktop />
        </DCArtboard>
        <DCArtboard id="result-m" label="모바일 · 결과" width={420} height={870}>
          <div className="frame-wrap"><IOSDevice width={390} height={844}><QuestResultMobile/></IOSDevice></div>
        </DCArtboard>
      </DCSection>

      <DCSection
        id="wrong"
        title="④ 오답 노트"
        subtitle="오답 누적 + 일괄 정복 보너스 + 시도 횟수 + 챕터 필터"
      >
        <DCArtboard id="wrong-d" label="데스크탑 · 오답" width={1160} height={1000}>
          <QuestWrongDesktop />
        </DCArtboard>
      </DCSection>

      <DCSection
        id="bookmarks"
        title="⑤ 북마크"
        subtitle="저장된 문제 + 개인 노트 + 카테고리"
      >
        <DCArtboard id="bm-d" label="데스크탑 · 북마크" width={1160} height={900}>
          <QuestBookmarksDesktop />
        </DCArtboard>
      </DCSection>
    </DesignCanvas>
  </>
);

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
