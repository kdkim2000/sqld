# Handoff: SQLD 합격길잡이 — Quest Mode Redesign

## Overview

기존 [sqld.vercel.app](https://sqld.vercel.app) (SQLD 자격증 학습 사이트)의 리디자인.
**듀오링고 스타일의 게이미피케이션** 방향으로, 마스코트(쿼리몬), 학습 경로, XP/하트/연속일 시스템을 도입.
라이트·다크 두 테마, 데스크탑 + 모바일 반응형.

페이지 5종:
1. **대시보드** — 오늘의 퀘스트 + 학습 경로 + 약점 챕터 + 주간 XP
2. **이론 학습 본문** — 본문 + 목차 + 마스코트 팁 + 코드 블록 + 관련 문제
3. **결과 화면** — 별·XP·보석 보상 + 도전과제 + 마스코트 진화 + 문제별 결과
4. **오답 노트** — 일괄 정복 + 시도 횟수 + 챕터 필터
5. **북마크** — 저장 문제 + 개인 노트 + 카테고리

---

## About the Design Files

이 번들의 파일은 **HTML로 제작된 디자인 레퍼런스** — 의도된 외관과 동작을 보여주는 프로토타입이지, 그대로 복사해 프로덕션에 쓸 코드가 아닙니다.

원본 sqld.vercel.app은 **Next.js**로 보이므로, 작업은 그 환경에서 동일한 패턴/라이브러리(React 컴포넌트, Tailwind 또는 CSS Modules, 기존 라우팅)를 따라 **재구현**하는 것입니다. 만약 다른 프레임워크라면 그쪽의 관례에 맞춰 옮기세요. HTML 그대로 배포하지 마세요.

프로토타입에는 디자인 캔버스(`design-canvas.jsx`)와 iOS 프레임 래퍼(`ios-frame.jsx`)가 포함돼 있는데, 이건 **여러 시안을 한 화면에 늘어놓기 위한 보조 도구**입니다. 실제 앱에는 필요 없습니다.

---

## Fidelity

**High-fidelity (hi-fi).**
색·타이포·간격·라운드·그림자·인터랙션 모두 최종 의도로 명시됨. 픽셀 단위로 맞추어 재현해 주세요.

단, **아이콘은 Lucide CDN**으로 임시 대체된 상태입니다(OPUS-X 디자인 시스템의 자체 아이콘 세트는 비공개). 실제 프로덕션에서는 sqld 기존 아이콘 또는 [`lucide-react`](https://lucide.dev/) 같은 동급 라이브러리로 대체하세요.

**마스코트(쿼리몬)** SVG 또한 임시 일러스트입니다. 운영 단계에서는 일러스트레이터가 제대로 그린 것으로 교체 권장 (또는 그대로 사용 가능).

---

## Tech Context

- **Font stack**: Noto Sans KR (본문/UI), Sora (디스플레이/숫자), Roboto Mono (코드/통계)
- **Color system**: OPUS-X (Samsung SDS) 디자인 시스템 기반의 보라(Purple) 프라이머리 팔레트
- **Icons**: Lucide (CDN으로 inline SVG)
- **Theme**: `<body data-theme="dark|light">` 데이터 속성으로 토글
- **State persistence**: 테마 토글은 `localStorage('q-theme')`에 저장

---

## Design Tokens

### Color

#### Brand purple (Primary)
```
purple-25:  #FAFAFF
purple-50:  #F4F3FF   ← tint backgrounds (e.g. nav active, mascot tip)
purple-100: #EBE9FE
purple-200: #D9D6FE
purple-300: #BDB4FE   ← light text on dark
purple-400: #9B8AFB
purple-500: #7F56D9   ← primary CTA, brand mark, path bubble
purple-600: #6941C6   ← gradient deep stop
purple-700: #53389E   ← primary CTA shadow lip (3D button), text on tint
purple-800: #42307D
purple-900: #2F1C6A
```

#### Functional / accent
```
mint (success):   #12B76A  (path: done 노드)
coral (life):     #FF6B6B  (mascot accent, hero gradient)
sun (XP):         #FFB627 / #FAC515  (achievement, streak flame)
sky (info):       #84CAFF
pink (highlight): #F670C7
```

#### Streak / Heart / Gem badge palettes (in top bar)
```
streak (orange): bg #FFF7ED / text #C2410C / border #FED7AA
gem    (purple): bg #F4F3FF / text #53389E / border #E9D5FF
heart  (red):    bg #FFF1F2 / text #BE123C / border #FECDD3
```

#### Light theme surface
```
bg-canvas:       #FBF9FF   ← page background
surface:         #FFFFFF   ← cards, top bar, nav
surface-soft:    #F9FAFB   ← subtle/inner zone
border:          #F2F4F7   ← card border
border-2:        #EAECF0   ← dividers
ink:             #101828   ← primary text
ink-2:           #475467   ← secondary text
ink-3:           #98A2B3   ← tertiary / labels
```

#### Dark theme surface
```
bg-canvas:       #0F0A28   ← page background
surface:         #1E1247   ← cards, top bar, nav
surface-soft:    rgba(255,255,255,.04)
border:          rgba(189,180,254,.12)
border-2:        rgba(189,180,254,.22)
ink:             #F4F3FF   ← primary text
ink-2:           #BDB4FE   ← secondary text
ink-3:           #9B8AFB   ← tertiary / labels
```

> **Implementation note**: The light values are the defaults on `.q-canvas`. The dark theme just redefines those CSS variables under `[data-theme="dark"] .q-canvas { ... }`. See `styles/quest-pages.css` lines 8–28 for the canonical mapping.

### Typography

| Token | Family | Size / Line-height | Weight | Used for |
|---|---|---|---|---|
| `--font-display` | **Sora** | 28–44/1.1 | 800 | Hero title, large numbers, page-header H1 |
| `--font-sans` | **Noto Sans KR** | 14–16/1.5 | 400/500/700 | Body, UI labels, card titles |
| `--font-mono` | **Roboto Mono** | 10–13/1.6 | 600/700 | Stats, percentages, code, kbd-like badges |

| Class / role | Font | Size | LH | Weight | Letter-spacing |
|---|---|---|---|---|---|
| Hero H1 | Sora | 28px (mobile 22) / 44 (result hero) | 1.1–1.2 | 800 | -0.02em |
| Card title | Noto Sans KR | 16 | 1.2 | 800 | normal |
| Body | Noto Sans KR | 14–15 | 1.5–1.7 | 400 | normal |
| Small label | Noto Sans KR | 11–12 | 1.3 | 600/700 | 0.04em |
| Stat number | Sora | 18–28 | 1.1 | 800 | -0.01em |
| Code block | Roboto Mono | 13 | 1.7 | 400/700 | normal |

### Spacing (4-point grid)

```
2 · 4 · 8 · 12 · 16 · 20 · 24 · 32 · 40 · 48 · 64
```

### Border radius

```
xs:    2
sm:    4
md:    6
lg:    8
xl:    12   ← standard card
2xl:   16   ← stat card
3xl:   20   ← prose card, hero
full:  999  ← pills, badges, progress
```

### Shadow

```
xs:  0 1px 2px 0 rgba(16,24,40,.05)
sm:  0 1px 3px 0 rgba(16,24,40,.10), 0 1px 2px 0 rgba(16,24,40,.06)
md:  0 4px 8px -2px rgba(16,24,40,.10), 0 2px 4px -2px rgba(16,24,40,.06)
3D-button (Duolingo style):
     bottom shadow lip = `0 6px 0 <deeper-color>`
     e.g. purple-500 bubble → `box-shadow: 0 6px 0 #53389E`
```

> 3D 버튼/노드의 "튀어나온" 느낌은 `box-shadow: 0 Npx 0 <deep>` 단단한 그림자로 만듭니다 — 듀오링고의 시그니처. CTA, path bubble, achievement card 등 게이미피케이션 요소에 적극 사용.

### Motion

```
--duration-fast:    120ms
--duration-medium:  200ms
--duration-slow:    320ms
--ease-standard:    cubic-bezier(.2,0,0,1)

Path node "현재" 강조 = q-bounce animation (1.6s ease-in-out infinite, translateY 0 → -6px)
Hover = translateY(-2px) 0.15s (3D card 효과)
Theme switch = body background transition 200ms
```

---

## Screens (상세 사양)

각 화면의 상세 layout은 프로토타입 JSX 파일을 정답지로 참조하세요. 파일 매핑:

| 화면 | 컴포넌트 | 파일 |
|---|---|---|
| 대시보드 (D) | `QuestDesktop` | `variants/quest.jsx` |
| 대시보드 (M) 홈 | `QuestMobile` | `variants/quest.jsx` |
| 대시보드 (M) 챕터 | `QuestMobileLesson` | `variants/quest.jsx` |
| 이론 (D) | `QuestTheoryDesktop` | `variants/quest-pages.jsx` |
| 이론 (M) | `QuestTheoryMobile` | `variants/quest-pages.jsx` |
| 결과 (D) | `QuestResultDesktop` | `variants/quest-pages.jsx` |
| 결과 (M) | `QuestResultMobile` | `variants/quest-pages.jsx` |
| 오답 (D) | `QuestWrongDesktop` | `variants/quest-pages.jsx` |
| 북마크 (D) | `QuestBookmarksDesktop` | `variants/quest-pages.jsx` |

공통 도구는 `variants/shared.jsx`:
- 아이콘 컴포넌트 (`IFlame`, `IGem`, `IHeart`, `IBook`, …) — Lucide 모양으로 직접 그린 SVG
- 마스코트 SVG (`Querymon` — 왕관 쓴 DB 캐릭터)
- 차트 (`ActivityRings`, `Radar`, `Sparkline`) — (이론·결과 페이지에서는 미사용; 다른 변형 디자인용)

### ① Dashboard — `QuestDesktop` / `QuestMobile`

**Desktop layout**
- Top bar (56px): 브랜드 + 글로벌 네비 + 우상단 통계 칩 3개(연속일🔥 / 보석💎 / 하트❤️) + 아바타
- Body grid: `1fr 360px` 2 column, gap 24
  - 왼쪽: 보라 그라데이션 hero 카드 (마스코트 + 오늘의 퀘스트) + 학습 경로 카드
  - 오른쪽: 마스코트 코멘트 카드 + 주간 XP 막대 그래프 + 약점 챕터 TOP 3

**학습 경로(Path)**
- 챕터를 지그재그로 배치된 노드로 시각화 (좌→우→좌→우…)
- 노드 상태: `done` (mint), `current` (purple, q-bounce animation), `locked` (gray with lock icon), `boss` (gold→coral gradient, 96px)
- 노드 간 점선 연결, 완료된 구간은 mint 실선

**Mobile layout**
- Top bar (compact pill 통계)
- Daily quest hero (마스코트 + 진행률)
- 3-column stat strip (풀이율 / 정답률 / 오늘 XP)
- 학습 경로 (zigzag, 세로 스크롤)
- Bottom tab nav 4개

### ② Theory — `QuestTheoryDesktop`

**Desktop layout**
- Top bar (재사용)
- Body grid: `280px 1fr 320px`
  - **TOC** (sticky): 목차 항목별 상태 (done / current / locked), 미니 시험 마지막
  - **본문**: 진행률 바, eyebrow 태그, H1 + 챕터 번호, lead 박스, H2 섹션들 (보라 vertical bar prefix), 코드블록 (다크 배경 + 토큰 컬러링), ER 테이블, 콜아웃 박스, 마스코트 팁 박스, footer (이전·다음 챕터 + XP 안내)
  - **사이드 레일**: 관련 문제 리스트, 학습 보상 카드, 추천 자료

**Code block 토큰 컬러링**
- 키워드 (`SELECT`, `CREATE`, `REFERENCES`): `#FCA5E5` bold
- 함수/식별자: `#FDE272`
- 리터럴/타입: `#6CE9A6`
- 주석: `#98A2B3` italic
- 배경: `#1A0F3E` (라이트·다크 양쪽 동일)

### ③ Result — `QuestResultDesktop`

**구성**
1. **컨페티** 백그라운드 (36개 색종이 조각, 결정론적 시드로 배치)
2. **Hero**: 마스코트 (waving) + "⭐ 미션 완료" 스탬프 + H1 (그라데이션 텍스트) + 별 3개
3. **Score grid**: 4개 카드 (정답률 / XP / 보석 / 시간)
4. **Achievement + Evolution row**: 도전과제 카드 (gold→coral gradient) + 마스코트 진화 카드 (purple gradient)
5. **Review strip**: 문제별 OX 결과 5행
6. **CTA**: Primary "다음 미션" + Secondary "오답 다시 풀기" / "결과 공유"

### ④ Wrong Answers — `QuestWrongDesktop`

- Page header (h1 + sub) + 탭 row (오답 / 정복함 / 건너뜀)
- KPI 행 (4 cards: 남은 오답 / 재정복 / 정복률 / 연속 정복)
- "한 번에 다 풀어보기" CTA 배너 (마스코트 + 보너스 안내)
- Question card list: 번호 / 챕터 태그·카테고리·난이도·시도횟수 태그 / 본문(2줄 truncate) / "다시 풀기" + "해설 보기" 버튼

### ⑤ Bookmarks — `QuestBookmarksDesktop`

오답 페이지와 동일 패턴, 다음 차이:
- 북마크 아이콘 (gold) 사용
- 개인 노트 옵션 (노란 left-border 인용구 박스로 표시)
- 탭: 모두 / 1과목 / 2과목 / 노트 있음
- KPI 행에 "북마크 문제 시험 1주 전 풀이 효과" tip 카드 포함

---

## Interactions & Behavior

### 테마 토글
- 우상단 floating button (모든 페이지 공통 — App 루트에 1개)
- 클릭 시 `body.dataset.theme` 토글 + `localStorage` 저장
- 새로고침 시 저장된 테마 복원
- 토글 자체에도 다크/라이트 스타일 적용 (knob slide)

### 학습 경로 노드
- Hover: `translateY(-2px)` 0.15s
- Current 노드: `q-bounce` infinite animation (1.6s, ease-in-out)
- Click: 챕터 미니 lesson 페이지로 이동 (실제 라우팅은 SPA의 routing에 위임)

### 3D 버튼 (primary CTA)
- Default: `box-shadow: 0 4px 0 <deep-color>` (마치 키캡처럼)
- Hover: 색상만 진해짐, transform 없음
- Active(누름): `translateY(2px)` + box-shadow 줄어듦 (선택 사항)

### 진행률 바 (모든 페이지)
- 트랙: `var(--gray-100)` or `var(--q-border)`, height 6–10px, radius 999
- Fill: `linear-gradient(90deg, #7F56D9, #BDB4FE)` 또는 단색 `#FAC515`
- 애니메이션 (선택): fill width transition 320ms ease-standard

### 컨페티 (결과 페이지)
- 36개 작은 사각 조각, 6색 (`#7F56D9`, `#FAC515`, `#FF6B6B`, `#12B76A`, `#84CAFF`, `#F670C7`)
- 결정론적 시드 (현재는 정적 배치) — 실제 구현에서는 [`canvas-confetti`](https://www.npmjs.com/package/canvas-confetti) 패키지로 결과 화면 진입 시 1.5s 동안 폭발 애니메이션 권장

### 마스코트 모션
- Hero 카드 안의 쿼리몬은 `wave` prop으로 한쪽 팔이 그려짐 (정적)
- 운영 단계에서 GSAP 또는 Lottie로 미세한 idle 모션(살짝 위아래) 추가 권장

---

## State Management

페이지마다 필요한 state:

### Dashboard
```ts
type DashboardData = {
  user: { name: string; avatar?: string; level: number; xp: number; xpToNext: number };
  streak: number;                        // days
  gems: number;
  hearts: { current: number; max: number };
  todayQuest?: {
    title: string;
    progress: number;                     // 0..1
    reward: { gems?: number; xp?: number };
  };
  path: ChapterNode[];                    // 5 chapters + 1 boss
  weakTop3: { name: string; rate: number }[];
  weeklyXp: { day: '월'|'화'|...; xp: number }[]; // 7 entries
  weekly: { goal: number; current: number };
  leagueRank?: { tier: string; rank: number };
};
type ChapterNode = {
  id: string;
  title: string; sub: string;
  state: 'done'|'current'|'locked'|'boss';
  icon: string;                           // emoji or icon key
  progress?: number;                      // 0..100, only for current
};
```

### Theory
```ts
type TheoryPage = {
  chapter: { id; title; partLabel: '1과목'|'2과목'; chapterNumber };
  progress: number;                       // 0..100
  toc: { title: string; done: boolean; current: boolean; mini?: boolean }[];
  content: TheoryBlock[];                 // rich content blocks
  relatedQuestions: { id; text; difficulty; done }[];
  nextChapter?: { id; title; locked? };
};
type TheoryBlock =
  | { kind: 'lead'; html: string }
  | { kind: 'h2'; text: string }
  | { kind: 'p'; html: string }            // supports <b>, .q-keyword spans
  | { kind: 'code'; language: 'sql'; lines: TokenizedLine[] }
  | { kind: 'table'; headers; rows }
  | { kind: 'callout'; variant: 'warning'|'info'; title; body }
  | { kind: 'mascot-tip'; body };
```

### Result
```ts
type ResultData = {
  chapter; lesson;
  total: number; correct: number;
  xp: number; gems: number;
  timeSpent: number;                       // seconds
  stars: 1|2|3;
  newAchievements: Achievement[];
  mascotEvolution?: { xpToNext: number; nextStage: string };
  questions: { n; correct; text; timeMs }[];
};
```

### Wrong / Bookmarks
```ts
type WrongQuestion = {
  id; chapterLabel; category; difficulty: '상'|'중'|'하';
  text: string; lastAttempt: Date; attemptCount: number;
};
type Bookmark = WrongQuestion & {
  note?: string;
  bookmarkedAt: Date;
};
```

### Theme
```ts
const [theme, setTheme] = useState<'light'|'dark'>(/* from localStorage */);
useEffect(() => {
  document.body.dataset.theme = theme;
  localStorage.setItem('q-theme', theme);
}, [theme]);
```

---

## Responsive Behavior

- **Desktop**: 1100px 이상 — 모든 grid 활성화
- **Tablet / narrow desktop**: 1100px 이하 — 사이드 패널이 본문 아래로 stack
  - 현재 CSS: `@media (max-width: 1100px) { .q-grid { grid-template-columns: 1fr; } }`
- **Mobile**: ≤ 480px — 별도 컴포넌트(`*Mobile`)로 만들어 두었음. 실제 구현에서는 같은 데이터 위에 다른 view component를 렌더링하거나, hooks(`useMediaQuery`)로 한 컴포넌트에서 분기.

> 모바일 컴포넌트는 iPhone (390×844) 가정. iOS frame 래퍼(`ios-frame.jsx`)는 시안 표현용. 실제로는 그냥 viewport 전체를 채우면 됩니다.

---

## Assets

| Asset | 출처 / 라이선스 | 비고 |
|---|---|---|
| **Querymon SVG** | 본 디자인 작업에서 직접 작성 (퍼블릭) | 임시 마스코트 — 운영 단계 일러스트 교체 권장 |
| **Lucide icons** | https://lucide.dev (ISC) | inline SVG로 변환되어 있음. `lucide-react` 패키지 사용 가능 |
| **Noto Sans KR / Noto Sans / Roboto Mono / Sora** | Google Fonts (Open Font License) | 라이선스 안전 |
| **Untitled UI / OPUS-X 컬러 팔레트** | 컬러 값만 사용 (값에 저작권 없음) | 토큰은 `colors_and_type.css`에 정리 |

> **Samsung Sharp Sans는 사용하지 않음**. OPUS-X 가이드에는 디스플레이 페이스로 언급되지만 비공개 폰트라 **Sora**(open source 대체)로 대체했음.

---

## File Map (이 번들)

```
prototype/
├─ index.html              ← 진입점 (모든 페이지를 디자인 캔버스에 늘어놓음)
├─ app2.jsx                ← App 컴포넌트 + 테마 토글 + 페이지 모음
├─ styles/
│  ├─ tokens.css           ← OPUS-X 디자인 토큰 (color / font / spacing / radius / shadow / motion)
│  ├─ app.css              ← 베이스 레이아웃 + Quest CSS (대시보드, 모바일)
│  └─ quest-pages.css      ← 추가 페이지 CSS + 다크 모드 오버라이드
├─ variants/
│  ├─ shared.jsx           ← 아이콘 + 마스코트 SVG + 차트 컴포넌트
│  ├─ quest.jsx            ← QuestDesktop / QuestMobile / QuestMobileLesson
│  ├─ quest-pages.jsx      ← Theory / Result / Wrong / Bookmarks (D + M)
│  ├─ pro.jsx              ← (참고) 채택 안 된 B 시안. 무시 가능
│  └─ rpg2.jsx             ← (참고) 채택 안 된 C 시안. 무시 가능
├─ design-canvas.jsx       ← 캔버스 helper (실 앱엔 불필요)
└─ ios-frame.jsx           ← 모바일 프레임 helper (실 앱엔 불필요)
```

### 프로토타입 실행

```bash
# 정적 서버 어느 것이든
cd prototype/
npx serve .
# 또는
python3 -m http.server 8000
```

`index.html`을 브라우저로 열면 5개 페이지 × 라이트/다크 토글이 한 캔버스에 표시됩니다. 디자인 캔버스에서 각 아트보드를 클릭하면 해당 화면이 풀스크린으로 확대돼 인터랙션을 자세히 확인할 수 있습니다.

---

## 구현 시 권장 순서

1. **토큰 먼저**: `tokens.css`의 CSS 변수를 코드베이스 토큰 시스템에 옮기기 (Tailwind config / CSS Module / styled-components theme 등 어느 쪽이든)
2. **마스코트와 아이콘**: `shared.jsx`에서 `Querymon`, `IFlame` 등의 컴포넌트 추출 → 별도 SVG 파일로 빼거나 React component로
3. **테마 토글**: `app2.jsx`의 `ThemeToggle` 패턴 — body data-attr + localStorage
4. **대시보드** (가장 임팩트 큼) → **결과** (보상감) → **이론** (가장 분량 많음) → **오답/북마크** (목록 패턴 동일)
5. **모바일은 desktop과 동일한 데이터를 받는 별도 컴포넌트** 또는 `useMediaQuery`로 분기

각 컴포넌트 JSX 안의 스타일은 인라인이거나 클래스명을 통해 CSS 파일과 연결되어 있습니다. 인라인 스타일은 그대로 옮기되, 반복되는 패턴(예: 3D 버튼)은 코드베이스의 컴포넌트로 추출하시는 게 좋습니다.

---

## 빠진 화면 (필요 시 추가 요청)

다음은 디자인 작업이 아직 안 됐습니다 — 필요하시면 알려주세요:

- 문제 풀이 진행 중 화면 (단일 문제 carousel) — desktop / mobile
- 모의고사 진행 중 (50문항 / 90분 타이머) — desktop / mobile
- 모의고사 결과 (Result와는 다른 시험 합격/불합격 화면)
- 리그 / 도감 / 프로필 / 설정 페이지
- 빈 상태 (오답 없음, 북마크 없음) 일러스트
- 로그인 / 회원가입

---

## Questions for Implementer

- 실 운영 환경의 디자인 시스템/UI 라이브러리(있다면 무엇?)에 본 디자인 토큰을 어떻게 매핑할지 결정 필요
- 마스코트는 직접 그린 임시 SVG — 운영 단계 일러스트레이션 교체 의향?
- 컨페티 애니메이션은 정적 — `canvas-confetti` 패키지 도입할지?
- 모바일 환경에서 별도 디자인 페이지를 유지할지, 또는 반응형으로 desktop 컴포넌트 안에 흡수할지?
